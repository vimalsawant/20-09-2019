export const environment = {
  name: 'prod',
  production: true,
  uriSegment: ''
};
