export const environment = {
    name: 'openshift',
    production: false,
    uriSegment: 'training'
  };
