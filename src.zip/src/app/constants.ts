/**
 * Purpose of this file is to raise awareness that a constant is being used across one or
 * several locations in this application.
 */

export const Constants = {
  jsonConfigLocation: 'assets/config/config.environment.json',
  httpRequestsTimeout:  300000, // 30 seconds.
  uriEnvironmentStringSubstitution: '{env}',
  jsonConfigSectionServiceContracts: 'serviceContractConfiguration',
  jsonConfigSectionOrchestrationService: 'spmOrchestrationService',
  jsonPayloadScIdReplacement: '{scId}',
  jsonCatalogKeyDataIntegrationStatus: '/actions/user-data-integration',
  jsonCOnfigSectionlastUpdateApplication: 'lastUpdateApplication',
  routerData: {
    catalogs: 'catalogsData',
    jsonConfigSection: 'catalogs'
  },
  UI: {
    responsiveModeBreakPoint: 768,
    maxChipLength: 30,
    snackBarDuration: {
        duration: 20000
    }
  }
};
