import { async, ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BrowserModule } from '@angular/platform-browser';
import { MatToolbarModule, MatPaginatorModule, MatTableModule, MatCardModule, MatFormField,
MatFormFieldModule, MatSelectModule, MatSpinner, MatMenuModule, MatButtonModule, MatInputModule,
MatProgressSpinnerModule, MatDialogModule } from '@angular/material';
import { AppRoutingModule } from '../app-routing.module';
import { LoginComponent } from './login.component';
import { LoginService } from './login.service';

describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;
  let h1:        HTMLElement;
  let authService: LoginService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
      MatTableModule,
      MatPaginatorModule,
      BrowserModule,
      BrowserAnimationsModule,
      MatMenuModule,
      MatButtonModule,
      MatFormFieldModule,
      MatInputModule,
      MatToolbarModule,
      MatCardModule,
      MatSelectModule,
      MatProgressSpinnerModule,
      MatDialogModule,
      AppRoutingModule
          ],
    declarations: [ LoginComponent ]
  });
  authService = TestBed.get(LoginService);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    h1 = fixture.nativeElement.querySelector('h1');
    fixture.detectChanges();
  });

  it('should have <h1> with  Welcome to OnePDL', () => {
    const loginElement: HTMLElement = fixture.nativeElement;
     h1 = loginElement.querySelector('h1');
    // expect(h1.textContent).toEqual('Welcome to OnePDL');
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('should be loginClick', fakeAsync(() => {
    component.loginClick();
    expect(component.loginClick).toBeDefined();
    component.processing = false;
    expect(component.processing).toBeDefined(false);
    tick(2001);
  }));

});
