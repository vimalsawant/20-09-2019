import { Component, OnInit } from '@angular/core';
import { LoginService } from './login.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  processing = false;
  constructor(public authService: LoginService, private router: Router) {
      this.router.navigate(['/catalogs/demand']);
   }
  ngOnInit() {
  }

  loginClick() {
    this.processing = true;
    setTimeout(() => {
      this.authService.isLoggedIn = true;
      this.processing = false;
    }, 2000
    );
  }
}
