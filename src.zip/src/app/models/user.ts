export class User {
    bemsId: string;
    password?: string;
    businessUnit?: string;
    displayName?: string;
}
