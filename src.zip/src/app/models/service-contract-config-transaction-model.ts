export class ServiceContractConfigTransactionModel {
    load: string; // "P",
    name: string; // "part-data",
    label: string; // "Part Master",
    description: string; // "Part Master SPM Integration"
}