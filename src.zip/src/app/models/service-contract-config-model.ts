import {ServiceContractConfigTransactionModel} from './service-contract-config-transaction-model';

export class ServiceContractConfigModel {
    scId: string; // "5d3769caa35b0800011be844"
    code: string; // "BCNOR",
    contractName: string; // "BCNOR",
    buId: string; // "BCASEL",
    link: string; // "sm://",
    instanceId: string; // "1",
    updatedDate: string; // "2019-08-21 15:21:15",
    status: number; // 1,
    transactions: ServiceContractConfigTransactionModel [];
}
