export class DataServiceParameters{
    // "http://onepdl-service-contract-config-service.{env}.apps.kcspre-clt.cloud.boeing.com/api-service/serviceContract/v1/criteria",
    getCatalogUri: string;
    getCatalogMethod: string; // "PUT",
    getCatalogDefaultPayloadBase64: string; // "ewogICAic3RhdHVzIiA6IDEKfQ=="
}