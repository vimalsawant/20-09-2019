import { Constants } from './constants';

describe('Constants', () => {
  it('should create an instance', () => {
    expect(Constants).toBeTruthy();
  });
});
