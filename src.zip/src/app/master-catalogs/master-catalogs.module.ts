import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { MasterCatalogsRoutingModule } from './master-catalogs-routing.module';

import {MatPaginatorModule} from '@angular/material/paginator';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import {MatTableModule} from '@angular/material/table';
import {MatChipsModule} from '@angular/material/chips';
import {MatInputModule} from '@angular/material/input';
import {MatSelectModule} from '@angular/material/select';
import {MatButtonModule} from '@angular/material/button';
import {MatDialogModule, MAT_DIALOG_DEFAULT_OPTIONS} from '@angular/material/dialog';
import {MatProgressBarModule} from '@angular/material/progress-bar';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {MatSortModule} from '@angular/material/sort';

import { TableComponent } from './table/table.component';
import { TableFilterComponent } from './table-filter/table-filter.component';
import { UploadComponent } from './dialogs/upload/upload.component';
import { EditUserComponent } from './dialogs/edit-user/edit-user.component';
import { UserDataIntegrationComponent } from './user-data-integration/user-data-integration.component';

@NgModule({
  declarations: [TableComponent, TableFilterComponent, UploadComponent, EditUserComponent, UserDataIntegrationComponent],
  imports: [
    CommonModule,
    MatPaginatorModule,
    MatProgressSpinnerModule,
    MatTableModule,
    MatChipsModule,
    MatInputModule,
    MatSelectModule,
    MatButtonModule,
    MatDialogModule,
    MatProgressBarModule,
    MatToolbarModule,
    MatCheckboxModule,
    MatSortModule,
    ReactiveFormsModule,
    MasterCatalogsRoutingModule
  ],
  entryComponents: [UploadComponent, EditUserComponent],
  providers: [
    {provide: MAT_DIALOG_DEFAULT_OPTIONS, useValue: {disableClose: true, hasBackdrop: true}}
  ]
})
export class MasterCatalogsModule { }
