import { TestBed, inject } from '@angular/core/testing';

import { CsvService } from './csv.service';

describe('CsvService', () => {
  let service: CsvService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [],
      declarations: [],
      providers: [CsvService],
    });
    service = TestBed.get(CsvService);
  });

  it('should be created', () => {
    // tslint:disable-next-line: no-shadowed-variable
    const service: CsvService = TestBed.get(CsvService);
    expect(service).toBeTruthy();
  });

  it('should call exportAsCsvFile', () => {
    // service.exportAsCsvFile();
    // expect(service.exportAsCsvFile).toBeDefined();
  });

  it('should call normalizeData', () => {
    // service.normalizeData();
    // expect(service.normalizeData).toBeDefined();
  });
});
