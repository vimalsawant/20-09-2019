import { Component, OnInit, ViewChild, AfterViewInit, ElementRef, NgZone, OnDestroy, Input } from '@angular/core';
import { TableDataSource } from './table-data-source';
import { MatPaginator } from '@angular/material/paginator';
import { MatDialog } from '@angular/material/dialog';
import { MatDialogRef, MatTable } from '@angular/material';
import { MatSnackBar } from '@angular/material';
import {MatSort} from '@angular/material/sort';

import { Observable, of, forkJoin } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { ActivatedRoute } from '@angular/router';

import { Constants } from '../../constants';

import { VmTable } from '../models/vm-table';
import { VmTableColumn } from '../models/vm-table-column';
import { VmTableRow } from '../models/vm-table-row';

import { TableFilterComponent } from '../table-filter/table-filter.component';
import { UploadComponent } from '../dialogs/upload/upload.component';
import { EditUserComponent } from '../dialogs/edit-user/edit-user.component';
import { ConfirmDialogComponent } from '../../layout/confirm-dialog/confirm-dialog.component';
import { ConfirmDialogModel } from 'src/app/layout/confirm-dialog/confirm-dialog-model';

import { DataService } from 'src/app/services/data.service';
import { CsvService } from '../csv.service';
import { UiService } from 'src/app/services/ui.service';
import { ServiceContractConfigService } from 'src/app/services/service-contract-config.service';

@Component({
    selector: 'app-table',
    templateUrl: './table.component.html',
    styleUrls: ['./table.component.scss']
})
export class TableComponent implements OnInit, OnDestroy, AfterViewInit {
    viewModel: VmTable;
    dataSource: TableDataSource;
    filterExpanded = true;
    loading = false;
    landingPage = true;
    disableSave = true;
    saveText: 'Save' | 'Saving' = 'Save';
    saveErrorCount: number;
    selectedRow: VmTableRow = null;
    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(TableFilterComponent) filter: TableFilterComponent;
    @ViewChild('thePaginator', {read: ElementRef}) paginatorRaw: ElementRef;
    @ViewChild(MatSort) sort: MatSort;
    @ViewChild(MatTable) table: MatTable<any>;
    @Input() // if set to true it will directly load all the data
    // without providing the option to either show filter or not.
    hideLoadOptions = false;
    // will hide all the other controls such as insert or upload.
    @Input()
    showRefreshControlOnly = false;

    confirmDialog: MatDialogRef<ConfirmDialogComponent> = null;

    constructor(private activatedRoute: ActivatedRoute,
        private matDialog: MatDialog,
        private dataService: DataService,
        private snackBar: MatSnackBar,
        public zone: NgZone,
        private csvService: CsvService,
        private uiService: UiService,
        private serviceContractService: ServiceContractConfigService) { }

    ngOnInit() {
        this.activatedRoute.data.subscribe((data) => {
            // we begin with an empty dataset.
            this.viewModel = new VmTable(data[Constants.routerData.catalogs],
                this.dataService, this.serviceContractService);
        });
        this.dataSource = new TableDataSource();
        this.uiService.setUnloadHandler(() =>
            this.disableSave ? '' : 'You have pending unsaved changes. Continue and discard changes?');
    }

    ngOnDestroy() {
        this.uiService.unsetUnloadHanlder();
    }

    ngAfterViewInit() {
        this.paginator.page.subscribe(() => {
            this.loading = true;
            this.loadVisibleData();
        } );
        this.filter.filterSelectionChanged.subscribe(() => {
            if (this.landingPage) {
                this.triggerBackendConnection(true);
            } else {
                this.loading = true;
                this.loadVisibleData(true);
            }
        });
        this.sort.sortChange.subscribe(() => {
            this.loading  = true;
            this.loadVisibleData(true);
        });
        if ( this.hideLoadOptions) {
            this.triggerBackendConnection();
        } else {
            this.loadVisibleData();
        }
        setTimeout(() => {
            // try to get sticky columns fixed:
            this.table.updateStickyColumnStyles();
        }, 300);
        // venturing outside Angular as it does not support capturing events.
        this.paginatorRaw.nativeElement.addEventListener('click', this.warnAboutChanges.bind(this), true);
    }

    warnAboutChanges(mouseEvent: MouseEvent) {
        if (!this.disableSave) {
            if (mouseEvent) {
                mouseEvent.stopPropagation();
            }
            // venturing outside Angular as it does not support capturing events.
            // this should get us back into angular's zone.
            this.zone.run(() => {
                this.confirmDialog = this.matDialog.open(ConfirmDialogComponent, {
                    width: '350px',
                    data: new ConfirmDialogModel(
                        'You have pending unsaved changes. Continue and discard changes?',
                        [['Discard unsaved changes', true], ['Cancel', false]])
                });
                this.confirmDialog.afterClosed().subscribe(result => {
                    if (result) { // User clicked 'Discard unsaved changes' and return result is true. 
                        // cleanup all the current data.
                        this.dataSource.renderedSubject.getValue().forEach(x => x.undoAllChanges());
                        this.disableSave = true;
                    }
                });
            });
        }
    }

    viewAllClick() {
        this.triggerBackendConnection();
    }

    /**
     * This is either first 'stage' of filtering, and then filter occurs on the client side.
     * Or it is also called on 'view all records'
     * @param calledFromFilter optional it needs to be true to filter the data.
     */
    triggerBackendConnection(calledFromFilter = false) {
        this.loading = true;
        this.viewModel.loadAllBackendData().subscribe(i => {
            // once data is loaded,  reset UI for sorting:
            this.sort.sort({disableClear: false, id: '', start: 'asc'});
            this.loadVisibleData(calledFromFilter);
            this.filterExpanded = false;
            this.filter.filterExpanded = false;
            if (this.landingPage) {
                this.landingPage = false;
            }
            this.loading = false;
            // prevent sorting in case that a some modification happened:
            // venturing outside Angular as it does not support capturing events.
            Array.from(document.querySelectorAll('th[mat-header-cell]')).forEach(tableHeaderElementRef => {
                tableHeaderElementRef.addEventListener('click', this.warnAboutChanges.bind(this), true);
            });
        },
        err =>
        this.matDialog.open(ConfirmDialogComponent, {
            width: '350px',
            data: new ConfirmDialogModel(
               'Error: ' + (err.message ? err.message : err), 'Accept')
        }).afterClosed().subscribe(() => this.loading = false)
        );
    }

    selectFilterClick() {
        this.filter.firstMatSelect.open();
    }

    /**
     * called when a pagination event happens
     * or when a filtering eveng happens
     * or on page load.
     * @param resetPaging should be true whenever new sorting or filtering criteria is being applied.
     */
    loadVisibleData(resetPaging?: boolean) {
        setTimeout(() => {
            try {
                let pageIndexParam = -1;
                if (resetPaging) {
                    this.paginator.pageIndex = 0;
                } else {
                    pageIndexParam = this.paginator.pageIndex;
                }
                // clean selection in case that it' there:
                this.selectedRow = null;
                this.dataSource.renderedSubject.next(
                    this.viewModel.retrieveData(pageIndexParam,
                        this.paginator.pageSize, this.filter.appliedFilterModel, this.sort));
            } finally {
                this.loading = false;
            }
        }, 700);
    }

    uploadClick() {
        this.matDialog.open(UploadComponent, { data: this.viewModel });
    }

    downloadClick() {
        if (!(this.filter.appliedFilterModel)) {
            this.csvService.exportAsCsvFile(this.viewModel.downloadData(false), this.viewModel.getColumsForTemplate(),
            'allData_' + this.viewModel.tableModel.itemName + '.csv');
        } else {
            // generate dialog:
            this.confirmDialog = this.matDialog.open(ConfirmDialogComponent, {
                data: new ConfirmDialogModel(
                    'Download All Results or Filtered Results?',
                    [['Download All', 'All'], ['Download Filtered', 'Filtered']], true)
            });
            this.confirmDialog.afterClosed().subscribe(result => {
                if (result === 'All') { // cleanup all the current data.
                    this.csvService.exportAsCsvFile(this.viewModel.downloadData(false), this.viewModel.getColumsForTemplate(),
                     'allData_' + this.viewModel.tableModel.itemName + '.csv');
                } else if (result === 'Filtered') {
                    this.csvService.exportAsCsvFile(this.viewModel.downloadData(true), this.viewModel.getColumsForTemplate(),
                     'filteredData_' + this.viewModel.tableModel.itemName + '.csv');
                }
            });
        }
    }

    /**
     * Reflects a change in the UI to be tracked.
     * @param newValue
     * @param internalColumnName
     * @param entireRow
     */
    cellChanged(newValue: any, column: VmTableColumn, row: VmTableRow) {
        if (row.patchValue(newValue, column)) {
            this.disableSave = false;
        } else {
            // recalculate if there's anything needed to be saved:
            this.disableSave = this.dataSource.renderedSubject.getValue().every(x => !x.dirty);
        }
    }

    saveClick() {
        this.saveText = 'Saving';
        this.disableSave = true;
        const currentData = this.dataSource.renderedSubject.getValue();
        const observables: Observable<any>[] = [];
        this.saveErrorCount = 0;
        if (currentData && currentData.length) {
            currentData.forEach((row, index) => {
                if (row.dirty) {
                    observables.push(row.commitChanges().pipe(map(x => x), catchError(x => of(this.saveErrorCount++))));
                }
            });
        }
        if (observables.length === 0) {
            this.snackBar.open('Nothing was saved as data is unchanged', 'Close', Constants.UI.snackBarDuration);
            this.saveText = 'Save';
        } else {
            window.setTimeout(() =>
            forkJoin(observables).subscribe(x => {
                this.saveText = 'Save';
                if (this.saveErrorCount) {
                    this.disableSave = false; // allow user to retry on errored rows
                    // gotta show a proper error message.
                    this.confirmDialog = this.matDialog.open(ConfirmDialogComponent, {
                        width: '350px',
                        data: new ConfirmDialogModel(
                            this.saveErrorCount + 'items failed while trying to save.', 'Accept')
                    });
                } else {
                    this.snackBar.open('Successfully saved ' + observables.length + ' rows.', 'Close', Constants.UI.snackBarDuration);
                }
            }), 1300);
        }
    }

    /**
     * Selects or deselects an item
     * Pending -- add property 'editItemEnabled' to Table model
     * @param z
     */
    rowClick(clickedRow: VmTableRow) {
        if (!this.viewModel.tableModel.enablePopupAddOrEdit) {
            return; // selecting an item , edit / add popup is disabled. Do nothing.
        }
        if (clickedRow === this.selectedRow) {
            this.selectedRow = null;
            return;
        }
        this.selectedRow = clickedRow;
    }

    /**
     * Shows a popup for to add new or edit currently selected user.
     */
    editItem(row?: VmTableRow) {
        if (!this.viewModel.tableModel.enablePopupAddOrEdit) {
            return; // selecting an item , edit / add popup is disabled. Do nothing.
        }
        this.matDialog.open(EditUserComponent, {
            width: '350px',
             data: [this.viewModel, row] });
    }


}
