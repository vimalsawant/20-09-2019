import { TableDataSource } from './table-data-source';

describe('TableDataSource', () => {
  it('should create an instance', () => {
    expect(TableDataSource).toBeTruthy();
  });
});
