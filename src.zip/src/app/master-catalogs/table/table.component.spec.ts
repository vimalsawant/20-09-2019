import { NgModule, DebugElement } from '@angular/core';
import { async, TestBed, ComponentFixture, fakeAsync, tick } from '@angular/core/testing';
import { MatPaginator } from '@angular/material/paginator';
import { MatDialog } from '@angular/material/dialog';
import { MatDialogRef, MatSnackBar } from '@angular/material';
import { RouterTestingModule } from '@angular/router/testing';
import { ActivatedRoute } from '@angular/router';

import { TableFilterComponent } from '../table-filter/table-filter.component';
import { UploadComponent } from '../dialogs/upload/upload.component';
import { ConfirmDialogComponent } from '../../layout/confirm-dialog/confirm-dialog.component';
import { ConfirmDialogModel } from 'src/app/layout/confirm-dialog/confirm-dialog-model';
import { TableComponent } from './table.component';

import { DataService } from 'src/app/services/data.service';
import { UiService } from 'src/app/services/ui.service';

describe('TableComponent', () => {
  let component: TableComponent;
  let fixture: ComponentFixture<TableComponent>;
  let debugElement: DebugElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [NgModule, RouterTestingModule, MatSnackBar, ConfirmDialogModel, MatDialog, MatPaginator, MatDialogRef],
      declarations: [TableComponent, UploadComponent, ConfirmDialogComponent, TableFilterComponent],
      providers: [
        { provide: ActivatedRoute, useValue: {} },
        { provide: MatSnackBar, useValue: {} },
        { provide: MatDialogRef, useValue: {} },
        { provide: UiService, useValue: {} },
        { provide: DataService, useValue: {} }
      ],
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    debugElement = fixture.debugElement;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have ngOnInit', () => {
    component.ngOnInit();
  });

  it('should have ngOnDestroy', () => {
    spyOn(component['uiService'], 'unsetUnloadHanlder');
    expect(component['uiService'].unsetUnloadHanlder).toHaveBeenCalledTimes(1);
  });

  it('should set pageLoaded after view init', () => {
    component.ngAfterViewInit();
    expect(component.loading).toBe(true);
    expect(component.loadVisibleData).toBe(true);
  });

  it('should have instance warnAboutChanges', () => {
    expect(component.warnAboutChanges).toBe(true);
  });

  it('should have viewAllClick', () => {
    component.viewAllClick();
    expect(component.viewAllClick).toBeDefined( null );
  });

  it('should have triggerBackendConnection', () => {
    component.triggerBackendConnection();
    expect(component.triggerBackendConnection).toBe(true);
    component.loading = false;
    expect(component.loading).toBe(false);
    component.filterExpanded = false;
    expect(component.filterExpanded).toBeFalsy(false);
    component.landingPage = false;
    expect(component.landingPage).toBeFalsy(false);
  });

  it('should have selectFilterClick', () => {
    component.selectFilterClick();
    expect(component.selectFilterClick).toBe(true);
  });

  it('should have loadVisibleData', () => {
    component.loadVisibleData();
    expect(component.loadVisibleData).toBeFalsy();
  });

  it('should hide after 800ms', fakeAsync(() => {
    tick(801);
    fixture.detectChanges();
  }));

  it('should have uploadClick', () => {
    component.uploadClick();
    expect(component.uploadClick).toBe(true);
  });

  it('should have downloadClick', () => {
    component.downloadClick();
    expect(component.downloadClick).toBe(true);
  });

  it('should have cellChanged', fakeAsync(() => {
    fixture.detectChanges();
    expect(component.cellChanged).toBe(true);
  }));

  it('should have saveClick', () => {
    component.saveClick();
    expect(component.saveClick).toBeUndefined();
    expect(component.saveText).toEqual('Saving');
  });

  it('should have setTimeout', fakeAsync(() => {
    tick(1301);
    fixture.detectChanges();
   }));
});
