import { DataSource, CollectionViewer } from '@angular/cdk/collections';
import { Observable, BehaviorSubject } from 'rxjs';
import { VmTableRow } from '../models/vm-table-row';


/**
 * Required interface implementation as per angular material's table
 */
export class TableDataSource extends DataSource <VmTableRow[]>  {

    get renderedSubject(): BehaviorSubject<VmTableRow[]> {
        return this.renderedSubjectPrivate;
    }
    private renderedSubjectPrivate = new BehaviorSubject<VmTableRow[]> ([]);
    private loadingDataSubject = new BehaviorSubject<boolean>(false);

    constructor() {
        super();
    }

    connect(collectionViewer: CollectionViewer): Observable<any> {
        return this.renderedSubjectPrivate.asObservable();
    }

    disconnect(collectionViewer: CollectionViewer) {
        this.renderedSubjectPrivate.complete();
        this.loadingDataSubject.complete();
    }


}
