import { Injectable } from '@angular/core';
import { saveAs } from 'file-saver';

@Injectable({
  providedIn: 'root'
})
export class CsvService {

  constructor() { }

  /**
   *
   * @param headers tuple array, [0] position is COLUMN HEADER TITLE (can have whitespaces)
   * [1] positoin is raw column Header ( Internal Name ) and can't have whitespaces.
   */
  public exportAsCsvFile(json: any[], headers: [string, string][], fileName: string) {
      let csvStr = '';
      let csvLine = '';
      if (headers && headers.length ) {
          headers.forEach(header => csvStr += (this.normalizeData(header[0]) + ','));
          csvStr = csvStr.slice(0, -1);
          csvStr += '\r\n';
      }
      if (json && json.length) {
        const jsonHeaders: string[] = [];
        headers.forEach(headerTuple => jsonHeaders.push(headerTuple[1]));
        json.forEach(jsonEntry => {
            csvLine = '';
            jsonHeaders.forEach(header => csvLine += this.normalizeData(jsonEntry[header]) + ',');
            csvLine = csvLine.slice(0, -1) + '\r\n';
            csvStr += csvLine;
        });
      }
      if (csvStr) {
          const blob = new Blob([csvStr], {type: 'text/plain;charset=utf-8'});
          saveAs(blob, fileName );
      }
  }

  private normalizeData(data: any): string {
      if (!data && data !== 0) { // null, undefined, emspty cases handled here - except zero.
          return '';
      }
      if (typeof data === 'string' && data.match(/\n|\"|,/gm) !== null) {
                return '"' + data.replace(/\"/g, '""') + '"';
      }
    return data;
  }
}
