import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TableComponent } from './table/table.component';
import { ResolverService } from '../services/resolver.service';
import { UserDataIntegrationComponent } from './user-data-integration/user-data-integration.component';

const routes: Routes = [{
  path: '',
  children: [
    // children meant for /catalogs/{whateverChildRouteName}, except for actions. (see below)
    {
       path: 'parts', component: TableComponent,
       resolve:
       {
         catalogsData: ResolverService
        },
    },
    {
      path: 'skus', component: TableComponent,
      resolve: {
        catalogsData: ResolverService
      }
    },
    {
      path: 'locations', component: TableComponent,
      resolve: {
        catalogsData: ResolverService
      }
    },
    {
      path: 'demand', component: TableComponent,
      resolve: {
        catalogsData: ResolverService
      }
    },
    {
      path: 'causal', component: TableComponent,
      resolve: {
        catalogsData: ResolverService
      }
    },
    {
        path: 'product-rollout', component: TableComponent,
        resolve: {
          catalogsData: ResolverService
        }
    },
    {
        path: 'product-bom', component: TableComponent,
        resolve: {
          catalogsData: ResolverService
        }
    },
    {
        path: 'users', component: TableComponent,
        resolve: {
          catalogsData: ResolverService
        }
    },
    {
        // meant for /actions/user-data-integration
        path: 'user-data-integration', component: UserDataIntegrationComponent,
        resolve: {
          catalogsData: ResolverService
        }
    }
  ]
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MasterCatalogsRoutingModule { }
