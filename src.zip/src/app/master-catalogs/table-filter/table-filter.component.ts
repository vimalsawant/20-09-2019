import { Component, OnInit, Input, EventEmitter, Output, ViewChild } from '@angular/core';
import { VmTableColumn } from '../models/vm-table-column';
import { FormBuilder } from '@angular/forms';
import { VmTableFilterCriteria } from '../models/vm-table-filter-criteria';
import { VmTable } from '../models/vm-table';
import { MatSelect } from '@angular/material';

@Component({
  selector: 'app-table-filter',
  templateUrl: './table-filter.component.html',
  styleUrls: ['./table-filter.component.scss']
})
export class TableFilterComponent implements OnInit {

  @Input()
  set tableViewModel(table: VmTable) {
    this._tableViewModel = table;
    this.columns = table.columns;
    this.orderedColumns = this.columns.filter(r => !(r.hidden)).map(c =>
        ({headerName: (c.headerName ? c.headerName : c.internalName), internalName: c.internalName}));
    this.orderedColumns.sort(function(a, b) {
        const x = a.headerName.toLocaleLowerCase();
        const y = b.headerName.toLocaleLowerCase();
        if (x < y) {return -1; }
        if (x > y) {return 1; }
        return 0;
      });
    this.partNumberColumnDisplayName = table.getDisplayNameOfPartNumberColumn();
  }
  get tableViewModel(): VmTable {
    return this._tableViewModel;
  }
  _tableViewModel: VmTable;

  partNumberColumnDisplayName: string;
  columns: VmTableColumn[];
  // column display or internal name in alphabetical order:
  orderedColumns: {headerName: string, internalName: string }[];
  editModel: VmTableFilterCriteria;
  appliedFilterModel: VmTableFilterCriteria = null;
  // Master property that drives the view into the chip mode or the applied filters view.
  editMode = true;
  private _filterExpanded = true;
  get filterExpanded(): boolean {
      return this._filterExpanded;
  }
  set filterExpanded (value) {
      this._filterExpanded = value;
      this.expandedChanged.emit(value);
  }
  @Input()
  allowFilter = true;

  @Output() expandedChanged: EventEmitter<boolean> = new EventEmitter();
  @Output() filterSelectionChanged: EventEmitter<null> = new EventEmitter();
  @Output() filterNotAllowed: EventEmitter<null> = new EventEmitter();
  @ViewChild('matSelectFilter') firstMatSelect: MatSelect;

  filterFocused = false; // used to save space (quick filter)
  private timeoutHolder: any;

  constructor(private fb: FormBuilder) {
  }

  ngOnInit() {
    // new empty model created
    this.editModel = new VmTableFilterCriteria(this.fb, null);
  }

  /**
   * It hides or shows the rest of the 'quick filter'
   * @param matSelectFilter is the MatSelect
   */
  selectOpenedChange(matSelectFilter) {
    if (matSelectFilter.value || matSelectFilter.focused || matSelectFilter.panelOpen) {
      this.filterFocused = true;
    }
    if (this.timeoutHolder) {
      clearTimeout(this.timeoutHolder);
    }
    this.timeoutHolder = setTimeout(() => {
      if (!matSelectFilter.value && !matSelectFilter.focused && !matSelectFilter.panelOpen) {
        this.filterFocused = false;
        this.timeoutHolder = null;
      }
    }, 1600);
  }

  /**
   * Once the filter is valid, we will call the service / server side code
   * Also generate the business objects that will hold the filter
   */
  applyFilter() {
    if (!this.allowFilter) {
        this.filterNotAllowed.emit();
        return;
    }
    this.appliedFilterModel = new VmTableFilterCriteria(null, this.editModel);
    this.editMode = false;
    this.filterSelectionChanged.emit();
  }

  cancel() {
    if (this.appliedFilterModel) {
      this.editMode = false;
    } else {
      this.editModel.clearAll();
      if (this._filterExpanded) {
        this.filterExpanded = false;
      } else {
        this.filterFocused = false;
      }
    }
  }

  removeChip(index: number) {
    if (!this.allowFilter) {
        this.filterNotAllowed.emit();
        return;
    }
    if (index === -1) {
      this.appliedFilterModel.clearPartNumber();
    } else {
        this.appliedFilterModel.removeCriterion(index);
    }
    if (this.appliedFilterModel.tableFilterCriteria.length === 0 && (!this.appliedFilterModel.partNumber)) {
      this.editModel.clearAll();
      this.filterFocused = false;
      this.editMode = true;
      this.appliedFilterModel = null;
    }
    this.filterSelectionChanged.emit();
  }

  clearAll() {
    if (!this.allowFilter) {
        this.filterNotAllowed.emit();
        return;
    }
    this.editModel.clearAll();
    this.filterFocused = false;
    if (this.editMode === false && this.filterExpanded) {
      this.filterExpanded = false;
    }
    this.editMode = true;
    this.appliedFilterModel = null;
    this.filterSelectionChanged.emit();
  }

  /**
   * copy model from appliedFilterModel.
   */
  editFilter() {
    this.editModel = new VmTableFilterCriteria(this.fb, this.appliedFilterModel);
    if (this.appliedFilterModel.partNumber || this.appliedFilterModel.tableFilterCriteria.length > 1) {
      this.filterExpanded = true;
    }
    this.editMode = true;
    this.filterFocused = true;
  }

  /**
   * When contracting sometimes we'll have to clear filters as contracted view don't support multiple
   *  criterion or part numbers.
   */
  expandContract() {
    if (this.filterExpanded && this.editMode ) {
      if ((this.appliedFilterModel) && (this.editModel.form.get('partNumber').value || this.editModel.tableFilterCriteria.length > 1)) {
        this.editMode = false;
      }
      if (!this.appliedFilterModel) {
        if (this.editModel.tableFilterCriteria.length === 1 && (!this.editModel.form.get('partNumber').value) &&
         this.editModel.hasNonEmptyValues()) {
            this.filterFocused = true;
        } else {
          this.editModel.clearAll();
          this.filterFocused = false;
        }
      }
    }
    this.filterExpanded = !this.filterExpanded;
  }

  private getColumn(internalName: string): VmTableColumn {
      return this.columns.find(c => c.internalName === internalName);
  }
}
