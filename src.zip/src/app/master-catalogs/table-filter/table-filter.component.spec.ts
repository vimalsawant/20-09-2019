import { async, ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ReactiveFormsModule, FormBuilder } from '@angular/forms';
import { MatButtonModule, MatInputModule, MatSelectModule, MatChipsModule } from '@angular/material';
import { DebugElement } from '@angular/core';

import { TableFilterComponent } from './table-filter.component';

describe('TableFilterComponent', () => {
  let component: TableFilterComponent;
  let fixture: ComponentFixture<TableFilterComponent>;
  let debugElement: DebugElement;


  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [TableFilterComponent],
      imports: [
        MatButtonModule,
        MatInputModule,
        MatSelectModule,
        MatChipsModule,
        ReactiveFormsModule,
        BrowserAnimationsModule
      ],
      providers: [
        FormBuilder
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TableFilterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    debugElement = fixture.debugElement;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should create an instance', () => {
    component = new TableFilterComponent(new FormBuilder());
    expect(component).toBeTruthy();
  });

  it('should call applyFilter method', () => {
    component.applyFilter();
    component.editMode = false;
    expect(component).toBeTruthy();
  });

  it('should emit on click', () => {
  });


  it('should cancel method', () => {
    component.cancel();
    expect(component.cancel).toBeTruthy();
    component.editMode = false;
    expect(component.editMode).toBe(false);
    component.filterFocused = false;
    expect(component.filterFocused).toBe(false);
  });

  it('should selectOpenedChange fakeasync', fakeAsync(() => {
    component.editMode = true;
    component.filterFocused = true;
    expect(component.filterFocused).toBe(true);
    tick(1700);
    fixture.detectChanges();
  }));


  it('should call removeChip method', () => {
    component.filterFocused = false;
    expect(component.filterFocused).toBe(false);
    component.editMode = true;
    expect(component.editMode).toBe(true);
    expect(component).toBeTruthy();
  });

  it('should call clearAll method', () => {
    component.clearAll();
    component.filterFocused = false;
    component.filterExpanded = false;
    component.editMode = true;
  });

  it('should call editFilter method', () => {
    component.editFilter();
    component.filterFocused = true;
    component.filterExpanded = true;
  });

  it('should call expandContract method', () => {
    component.expandContract();
    component.editMode = false;
    component.filterFocused = true;
  });

  it('ngOnInit method', () => {
    component.ngOnInit();
  });
});

