import { VmTableColumn } from './vm-table-column';
import { VmTableFilterCriteria } from './vm-table-filter-criteria';
import { ModelTable } from './model-table';
import { VmTableRow } from './vm-table-row';
import { DataService } from 'src/app/services/data.service';
import { tap, switchMap, map } from 'rxjs/operators';
import { Observable, throwError, of, forkJoin } from 'rxjs';
import { MatSort } from '@angular/material/sort';
import { ServiceContractConfigService } from 'src/app/services/service-contract-config.service';
import { Constants } from 'src/app/constants';
import { VmServiceContractConfig } from '../user-data-integration/models/vm-service-contract-config';

export class VmTable {
    columns: VmTableColumn [] = [];
    columnNames: string [];
    // ideally once the server side connection comes we will use only
    // one property for data and not 2.
    allRawData: any [];
    filteredSortedData: any [];
    dataSourceLength: number;
    // this will define whether the partNumber filter textarea can be shown or not.
    hasPartNumberColumn: boolean;

    /**
     * Mocking the connection to the backend with a constructor
     * that can accept MOCK JSON.
     */
    constructor(public tableModel: ModelTable, public dataService: DataService,
        private serviceContractService: ServiceContractConfigService) {
        // by default we begin with an empty table.
        this.allRawData = [];
        this.initializeColumns();
    }

    /**
     * Connects to the backend servic(es) to provide data.
     * 1. Retrieve service contract Id for current environment
     * 2. Retrieve data utilizing provided service contract id
     * 3. Gracefully returns error in case of 'null'
     * 4. Taps Data to internally intialize component
     */
    loadAllBackendData(): Observable<any[]> {
        // point 1
        return this.serviceContractService.getCurrentScId().pipe(
            // point 2
            switchMap(scId =>
                this.dataService.invoke<any[]>(this.tableModel.getCatalogUri, this.tableModel.getCatalogMethod,
                atob(this.tableModel.getCatalogDefaultPayloadBase64).replace(
                    Constants.jsonPayloadScIdReplacement, scId))),
            // point 3
            switchMap(result => {
                        if (!result) {
                            return throwError('Service returned an unexpected null value');
                        }
                        if (this.tableModel.key === '/catalogs/users') {
                            return of([{
                            UserID: '123',
                            ServiceContractID: 'SC1, SC2',
                            FirstName: 'Matt',
                            LastName: 'Dean',
                            Email: 'mattdean@boeing.com',
                            UserType: 'Boeing Person',
                            Active: 'Yes',
                            CreatedBy: 'Katie Fang',
                            CreatedDate: '8/8/19',
                            UpdatedBy: 'Katie Fang',
                            UpdatedDate: '8/8/19'
                        }, {
                            UserID: '421',
                            ServiceContractID: 'SC3, SC4',
                            FirstName: 'John',
                            LastName: 'Doe',
                            Email: 'johndoe@boeing.com',
                            UserType: 'Non Boeing Person',
                            Active: 'Yes',
                            CreatedBy: 'Katie Fang',
                            CreatedDate: '8/8/19',
                            UpdatedBy: 'Katie Fang',
                            UpdatedDate: '8/8/19'
                        }, {
                            UserID: '1121',
                            ServiceContractID: 'SC1, SC2, SC3, SC4, SC5',
                            FirstName: 'Samuel',
                            LastName: 'Smith',
                            Email: 'samuelsmith@boeing.com',
                            UserType: 'Boeing Person',
                            Active: 'Yes',
                            CreatedBy: 'Katie Fang',
                            CreatedDate: '8/8/19',
                            UpdatedBy: 'Katie Fang',
                            UpdatedDate: '8/8/19'
                        }, {
                            UserID: '4532',
                            ServiceContractID: 'SC1',
                            FirstName: 'Katie',
                            LastName: 'Fang',
                            Email: 'katie.fang@boeing.com',
                            UserType: 'Boeing Person',
                            Active: 'Yes',
                            CreatedBy: 'Akbar Zindani',
                            CreatedDate: '7/4/19',
                            UpdatedBy: 'Akbar Zindani',
                            UpdatedDate: '7/4/19'
                        }]);
                        }
                        if (this.tableModel.key === Constants.jsonCatalogKeyDataIntegrationStatus) {
                            const vm = new VmServiceContractConfig(this.serviceContractService);
                            return forkJoin(of(result), vm.getCurrentTransactions()).pipe(
                                map(x => {
                                    const labelCatalog = x && x[1];
                                    const data = x && x[0];
                                    if (data && data.length) {
                                        data.forEach(element => {
                                            // Converting date format to a human readable one.
                                            // expected input format: "2019-09-09T21:13:28.420+0000"
                                            // output : "2019-09-09 21:13 UTC"
                                            if (element.createdDate && element.createdDate.length && element.createdDate.length >= 16) {
                                                element.createdDate = element.createdDate.replace('T', ' ').substring(0, 16) + ' UTC';
                                            }
                                            // Mapping the transaction name to a 'UI name' / label one.
                                            // example(s): transactionType: "orderplan-data" -> 'Order Plan'
                                            // example 2 : transactionType: "stock-data" -> 'Stock'
                                            if (element.transactionType && labelCatalog && labelCatalog.length &&
                                                labelCatalog.find(y => y.model.name === element.transactionType)) {
                                                element.transactionType =
                                                labelCatalog.find(z => z.model.name === element.transactionType).model.label;
                                            }
                                        });
                                        data.sort((a, b) => b.downloadId - a.downloadId);
                                    }
                                    return data;
                                })
                            );

                        }
                        return of(result);
                    }),
            // point 4
            tap(data => {
                        this.allRawData =  data;
                        this.initializeColumns();
                    })
        );
    }

    /**
     * Sets up columns according to tableModel.columns.
     * if hideNonRegisteredColumns is false, it tries to autodetect and append unregistered columns
     */
    initializeColumns() {
        if (this.tableModel && this.tableModel.columns ) {
          this.columns = this.tableModel.columns;
          if (!this.tableModel.hideNonRegisteredColumns) {
            // append columns that are not pre-registered
            this.autoDetectColumns(this.allRawData);
          }
        } else {
          this.autoDetectColumns(this.allRawData);
        }
        this.columns.sort((a, b) => {
          if (a.order === b.order) {
            return 0;
          } else if ((a.order === null) || typeof(a.order) === 'undefined') {
            return 1;
          } else  if ((b.order === null) || typeof(b.order) === 'undefined') {
            return -1;
          }
          return a.order > b.order ? 1 : -1;
        });
        // hides clumns from the html table  of the table but are still used in other places
        this.columnNames = this.columns.filter(x => !(x.hidden)).map(column => column.internalName);
        this.dataSourceLength = this.allRawData.length;
    }

    /**
     *
     * Simulates pagination and filtering.
     * In futire it should connect to the microservice.
     *
     * Client side sorting, filtering and paging are left as raw data processing :
     * 1. for perfoamnce reasons
     * 2. because it may get server side implemented in the future.
     *
     * @param pageIndex Pagination from server should be more solid and be coursor based,
     *      send  -1 to make pageIndex zero and apply filter
     * @param pageSize  the number of records to retrieve
     * @param filterCriteria send it  along with -1 in pageINdex to filter.
     */
    retrieveData(pageIndex: number, pageSize: number, filterCriteria: VmTableFilterCriteria, matSort: MatSort): VmTableRow[] {
        if (pageIndex === -1) {
            // means filter or sorting is being applied (or cleared)
            pageIndex = 0;
            this.applyClientSideFilter(filterCriteria);
            this.applyClientSideSorting(matSort);
        }
        const startIndex = pageIndex * pageSize;
        const sourceData = this.filteredSortedData || this.allRawData;
        this.dataSourceLength = sourceData.length;
        return sourceData.slice( startIndex, startIndex + pageSize).map(x => new VmTableRow(x, this));
    }

    private applyClientSideSorting(sort: MatSort) {
        if (!sort.active || sort.direction === '') {
            return ;
        }
        let sourceData = this.filteredSortedData || this.allRawData;
        sourceData = sourceData.slice(); // reference copy of the array.
        const sortColumn = this.columns.find(column => column.internalName === sort.active);
        const sortAscending = sort.direction === 'asc';
        sourceData.sort((a, b) => {
            if (typeof (a[sort.active]) === 'undefined' || a[sort.active] === null) {
                if (typeof(b[sort.active]) === 'undefined' || b[sort.active] === null) {
                    return 0;
                }
                return sortAscending ? -1 : 1;
            }
            if (typeof (b[sort.active]) === 'undefined' || b[sort.active] === null) {
                return sortAscending ? 1 : -1;
            }
            if (sortColumn.columnType === 'OnePDLCurrency' || sortColumn.columnType === 'OnePDLNumber' ||
            sortColumn.columnType === 'OnePDLCheckbox') {
                return sortAscending ? a[sort.active] - b[sort.active] : b[sort.active] - a[sort.active];
            }
            const aString = <string> a[sort.active];
            const bString = <string> b[sort.active];
            return sortAscending ? aString.localeCompare(bString) : bString.localeCompare(aString);
        });
        this.filteredSortedData = sourceData;
    }


     /**
   * Temporary Client side filtering.
   */
  private applyClientSideFilter(filterCriteria: VmTableFilterCriteria) {
    if (!filterCriteria) {
      this.filteredSortedData = null;
      return ;
    }
    // begin with an unfiltered catalog.
    this.filteredSortedData = this.allRawData;
    if (filterCriteria.partNumber) {
      let separator = '\n';
      if (filterCriteria.partNumber.indexOf(',') >= 0) {
        separator = ',';
      }
      if (filterCriteria.partNumber.indexOf(';') >= 0) {
        separator = ';';
      }
      const parts: string [] = filterCriteria.partNumber.split(separator).map(x => x.toLowerCase().trim());
      this.filteredSortedData = this.filteredSortedData.filter(x =>
                parts.indexOf(x[this.tableModel.partNumberColumnName].toLowerCase().trim()) >= 0);
    }

    // filter based on the rest of the columns.
    if (filterCriteria.tableFilterCriteria && filterCriteria.tableFilterCriteria.length) {
      this.filteredSortedData = this.filteredSortedData.filter( x =>
        // if one criteria fails then we return false.
        !filterCriteria.tableFilterCriteria.some( criterion => {
            let columnValue = x[criterion.column.internalName];
            if (typeof columnValue === 'string' && columnValue) {
              columnValue = columnValue.trim().toLowerCase();
            }
            let filterValue = criterion.filterValue;
            if (typeof filterValue === 'string' && columnValue) {
              filterValue = filterValue.trim().toLowerCase();
            }
            return !criterion.operator.compare(columnValue, filterValue);
          }
        )
      );
    }
  }

  getDisplayNameOfPartNumberColumn() {
    let rValue = '';
    let foundColumn: VmTableColumn;
    if (this.tableModel.partNumberColumnName && this.columns && this.columns.length) {
      foundColumn = this.columns.find(x => x.internalName === this.tableModel.partNumberColumnName );
      if (foundColumn) {
        rValue = foundColumn.headerName || foundColumn.internalName;
      }
    }
    return rValue;
  }

    /**
     * Checks against the current 'this.columns' object and looks for the column's internal names
     * If they are not existenti, then it adds those columns.
     */
    private autoDetectColumns( initialCatalog: any[]) {
        if (initialCatalog && initialCatalog.length && initialCatalog[0]) {
            for (const colName in initialCatalog[0]) {
                if (initialCatalog[0].hasOwnProperty(colName)) {
                    if (this.columns.filter( x => x.internalName === colName).length === 0) {
                        if (typeof initialCatalog[0][colName] === 'number') {
                                this.columns.push({
                                    headerName: colName,
                                    columnType: 'OnePDLNumber',
                                    internalName: colName,
                                });
                        } else {
                            this.columns.push({
                                headerName: colName,
                                columnType: 'OnePDLString',
                                internalName: colName,
                            });
                        }
                    }
                }
            }
        }
    }

    /**
     * Used for downloading excel template
     *  returns an array of tuples where position 0 is friendly Title ( can contain spaces)
     * and postion 1 is internal name (can't contain spaces)
     */
    public getColumsForTemplate(): [string, string][] {
        return this.columns.filter(x => !(x.hidden)).map(column => <[string, string]> [column.headerName, column.internalName]);
    }

    public downloadData(useFilter: boolean): any[] {
        return useFilter ? this.filteredSortedData : this.allRawData;
    }
}
