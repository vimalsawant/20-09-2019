import { VmTableColumn } from './vm-table-column';

describe('VmTableColumn', () => {
  it('should create an instance', () => {
    expect(new VmTableColumn()).toBeTruthy();
  });
});
