import { VmTableColumn } from './vm-table-column';
import { VmTable } from './vm-table';
import { Observable, of } from 'rxjs';
import { tap, map } from 'rxjs/operators';

/**
 * To avoid bloating will try to stay away from reactive forms and VmTableCell objects.
 * Let's see if this approach pays of in performance terms.
 */
export class VmTableRow {
    dirty = false;
    changedData = {};
    constructor(public originalData: any, private parentTable: VmTable) {}

    /**
     * invoked any time a cell is changed.
     * @param newValue
     * @param column
     */
    patchValue(newValue: any, column: VmTableColumn): boolean {
        const backendValue: any = this.getBackendValue(newValue, column);
        if (typeof (this.changedData[column.internalName]) !== 'undefined') {
            if ( this.changedData[column.internalName] !== backendValue ) {
                this.changedData[column.internalName] = backendValue;
                // then compare against original value and if things are same, cancel this change.
                if ( this.originalData[column.internalName] !== backendValue ) {
                    this.dirty = true;
                    return true;
                } else {
                    // same as original data, erase change object entry
                    delete this.changedData[column.internalName];
                }
            }
        } else if ( this.originalData[column.internalName] !== backendValue ) {
            this.changedData[column.internalName] = backendValue;
            this.dirty = true;
            return true;
        }
        this.recalculateDirty();
        return false;
    }

    public getRowValue(columnName: string) {
        if (typeof(this.changedData[columnName]) !== 'undefined') {
            return this.changedData[columnName];
        }
        return this.originalData[columnName];
    }

    private recalculateDirty() {
        if (Object.keys(this.changedData).length === 0 ) {
            this.dirty = false;
        }
    }

    /**
     * Finds out if the cell has changed
     * 
     * @param columnName must be the column's internal name.
     */
    hasCellChanged(columnName: string): boolean {
        return typeof(this.changedData[columnName]) !== 'undefined';
    }

    /**
     * Acts as a translator or dictionary between UI controls and actual JSON value that is persisted 
     * in the backend microservice.
     */

    private getBackendValue(newValue: any, column: VmTableColumn) {
        switch(column.columnType) {
            case 'OnePDLCheckbox': return newValue ? 1 : 0;
            default: return newValue;
        }
    }


    /**
     *  Gets rid of the changes that have been made on the clientside.
     */
    undoAllChanges() {
        this.changedData = {};
        this.dirty = false;
    }

    /**
     * ONLY IF THE ITEM IS DIRTY, it will try to reach the backend and sync the changes.
     */
    public commitChanges(): Observable<any> {
        if (this.dirty) {
            const submitObject = {};
            Object.assign(submitObject, this.originalData);
            // then we overwrite the delta:
            Object.assign(submitObject, this.changedData);
            return this.parentTable.dataService.invoke(this.parentTable.tableModel.saveItemUri, 'POST' , submitObject).pipe(
                tap( x => {
                    // this is done when successfully saved:
                    this.undoAllChanges();
                    // doing this way instead of an '=' assingment because client side is handing ALL DATA (sorting, paging etc.)
                    Object.assign(this.originalData, submitObject);
                })
               );
        } else {
            return of('');
        }
    }

}
