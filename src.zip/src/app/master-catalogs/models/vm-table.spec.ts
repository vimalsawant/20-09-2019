import { VmTable } from './vm-table';
import { VmTableColumn } from './vm-table-column';
import { VmTableFilterCriteria } from './vm-table-filter-criteria';
import { ModelTable } from './model-table';
import { VmTableRow } from './vm-table-row';
import { DataService } from 'src/app/services/data.service';
import { ServiceContractConfigService } from 'src/app/services/service-contract-config.service';
import { Constants } from 'src/app/constants';
import { VmServiceContractConfig } from '../user-data-integration/models/vm-service-contract-config';
import { TestBed } from '@angular/core/testing';
import { HttpClientModule } from '@angular/common/http';
import { MatSort } from '@angular/material/sort';

describe('VmTable', () => {
  let dataservice: DataService;
  let tableModel: ModelTable;
  let serviceContractService: ServiceContractConfigService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientModule, MatSort],
      declarations: [ ],
      providers: [DataService, ModelTable, ServiceContractConfigService],
    });
    dataservice = TestBed.get(DataService);
    tableModel = TestBed.get(ModelTable);
    serviceContractService = TestBed.get(ServiceContractConfigService);
  });

  it('should create an instance', () => {
    expect(VmTable).toBeTruthy();
  });

  it('should create an loadAllBackendData', () => {
  });
  it('should call initializeColumns', () => { });
  it('should call retrieveData', () => { });
  it('should call applyClientSideSorting', () => { });
  it('should call applyClientSideFilter', () => { });
  it('should call getDisplayNameOfPartNumberColumn', () => { });
  it('should call autoDetectColumns', () => { });
  it('should call getColumsForTemplate', () => { });
  it('should call downloadData', () => {

  });
});
