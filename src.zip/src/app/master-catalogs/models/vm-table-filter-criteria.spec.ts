import { VmTableFilterCriteria } from './vm-table-filter-criteria';
import { FormBuilder } from '@angular/forms';
import { VmTableFilterCriterion } from './vm-table-filter-criterion';

describe('VmTableFilterCriteria', () => {
  let classToTest: VmTableFilterCriteria;
  let classToTests: VmTableFilterCriterion;

  it('should create an instance', () => {
    classToTest = new VmTableFilterCriteria(new FormBuilder(), new VmTableFilterCriteria(null, null));
    expect(classToTest).toBeTruthy();
  });
  it('should create an instance', () => {
    classToTests = new VmTableFilterCriterion(null, new FormBuilder());
    expect(classToTests).toBeTruthy();
  });

  it('isDirty', () => {
    const isDirt = classToTest.isDirty();
    expect(isDirt).toBeFalsy();
  });

  it('validForApplying', () => {
    const validFor = classToTest.validForApplying();
    expect(validFor).toBeFalsy();
  });

  it('it has non empty values', () => {
    const nonEmpty = classToTest.hasNonEmptyValues();
    expect(nonEmpty).toBeFalsy();
  });

  it('clears Part Number', () => {
    const partNumber = classToTest.clearPartNumber();
    expect(partNumber).toBeFalsy();
  });

  it('clear All', () => {
    const allClear = classToTest.clearAll();
    expect(allClear).toBeFalsy();
  });

  it('add new criterion', () => {
    const allClear = classToTest.addNewCriterion();
    expect(allClear).toBeFalsy();
  });

  it('should create an instance', () => {
    classToTests = new VmTableFilterCriterion(null, new FormBuilder());
    expect(classToTests).toBeTruthy();
  });

  it('should create an instance', () => {
    classToTest = new VmTableFilterCriteria(new FormBuilder(), null);
    expect(classToTest).toBeTruthy();
  });

  it('should create an instance', () => {
    classToTest = new VmTableFilterCriteria(new FormBuilder(), classToTest);
    expect(classToTest).toBeTruthy();
  });

  it('should create an instance', () => {
    classToTest = new VmTableFilterCriteria(null, classToTest);
    expect(classToTest).toBeTruthy();
  });

  it('valid For Applying', () => {
    classToTests = new VmTableFilterCriterion(classToTests, null);
    expect(classToTests).toBeTruthy();
  });

  it('valid For Applying remove criterion', () => {
    const val = classToTest.removeCriterion(null);
    expect(val).toBeUndefined();
  });
});
