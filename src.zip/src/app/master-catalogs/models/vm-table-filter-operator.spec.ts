import { VmTableFilterOperator } from './vm-table-filter-operator';

describe('VmTableFilter', () => {
  it('should create an instance', () => {
    expect(new VmTableFilterOperator()).toBeTruthy();
  });
});
