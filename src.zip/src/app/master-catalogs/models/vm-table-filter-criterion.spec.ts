import { VmTableFilterCriterion } from './vm-table-filter-criterion';
import { VmTableFilterOperator } from './vm-table-filter-operator';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { VmTableColumn } from './vm-table-column';

describe('VmTableFilterCriterion', () => {

  let classToTest: VmTableFilterCriterion;
  let classToTestOperator: VmTableFilterOperator;
  let classToTestForm: FormControl;
  let classToTestTableColumn: VmTableColumn;

  it('should instantiate VmTableFilterCriterion', () => {
    classToTest = new VmTableFilterCriterion(null, new FormBuilder());
    expect(classToTest).toBeTruthy();
    const getCOlumnResult = classToTest.getColumnFilters();
    expect(getCOlumnResult).toBeTruthy();
  });

  it('should instantiate VmTableFilterOperator', () => {
    classToTestOperator = new VmTableFilterOperator();
    expect(classToTestOperator).toBeTruthy();

  });

  it('should instantiate VmTableColumn', () => {
    classToTestTableColumn = new VmTableColumn();
    expect(classToTestTableColumn).toBeTruthy();
  });

  it('should instantiate FormControl', () => {
    classToTestForm = new FormControl();
    expect(classToTestForm).toBeTruthy();
  });

  it('should call getColumnFilters', () => { });

  it('should call requiredValue', () => { });

  it('should call toString', () => { });

  it('to String', () => {
    const operatorTest: VmTableFilterOperator = { displayName: 'testDisplay' };
    expect(operatorTest).toBeDefined();
  });


  it('Instance invoking subscriber', () => {
    classToTest = new VmTableFilterCriterion(null, new FormBuilder());
    classToTestOperator = new VmTableFilterOperator();
    classToTest.form.get('operator').patchValue(null);
    classToTest.form.get('column').patchValue(null);
    classToTest.form.get('operator').patchValue(classToTestOperator);
    classToTest.form.get('operator').patchValue(classToTestForm);
    const criterionTest = new VmTableFilterCriterion(classToTest, new FormBuilder());
    expect(criterionTest).toBeTruthy();
  });

  it('should take classToTest as param ', () => {
    const app = new VmTableFilterCriterion(classToTest, null);
    expect(app).toBeTruthy();
  });

  it('should call requiredValue', () => {
    const operatorValue = classToTest.requiredValue();
    expect(operatorValue).toBeTruthy();

  });

  it('should call requiredValue1', () => {
    classToTest = new VmTableFilterCriterion(null, new FormBuilder());
    const valueFormControl: FormControl = <FormControl>classToTest.form.get('operator');
    const operator: VmTableFilterOperator = { displayName: 'testDisplayName', omitFilterValue: true };
    classToTest.operator = { displayName: 'testDisplayName', omitFilterValue: false };
    valueFormControl.setValue(operator);
  });

  it('should call requiredValue2', () => {
    classToTest = new VmTableFilterCriterion(null, new FormBuilder());
    const valueFormControl: FormControl = <FormControl>classToTest.form.get('operator');
    const operator: VmTableFilterOperator = { displayName: 'testDisplayName', omitFilterValue: true };
    classToTest.operator = { displayName: 'testDisplayName', omitFilterValue: true };
    valueFormControl.setValue(operator);
  });
});

