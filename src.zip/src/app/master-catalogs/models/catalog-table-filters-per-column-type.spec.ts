import { TABLE_FILTERS_PER_COLUMN_TYPE } from './catalog-table-filters-per-column-type';

describe('TableFiltersPerColumnType', () => {
  it('should create an instance', () => {
    expect(TABLE_FILTERS_PER_COLUMN_TYPE).toBeTruthy();
  });
});
