import { TABLE_COLUMN_TYPES } from './catalog-table-column-types';

// Configuration model for the columns and for the viewmodel
// as long as columns are not implementing behavior, we can reuse that object
// otherwise, we will need to create a ModelTableColumn class with JSON only properties.
export class VmTableColumn {
    columnId?: number; // unique ID
    headerName: string; // what needs to be shown in the header
    columnType: TABLE_COLUMN_TYPES; // type of supported column.
    internalName: string; // name that comes from JSON
    sticky?: boolean; // must be false,  null or undefined for non sticky.
    hidden?: boolean; // must be true to hide it.
    order?: number; //  display order of the columns.
    editable?: boolean; // whether field is editable or not
    required?: boolean; // whether the field is required or not.
    maxLength?: number; // max length for the field.
    defaultValue?: string; // the default value for new forms.
    description?: string; // a description of the field (new  / edit forms)
}
