import { ModelTable } from './model-table';

describe('ModelTable', () => {
  it('should create an instance', () => {
    expect(new ModelTable()).toBeTruthy();
  });
});
