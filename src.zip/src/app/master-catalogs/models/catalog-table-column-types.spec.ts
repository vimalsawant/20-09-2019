import {TABLE_COLUMN_TYPES} from './catalog-table-column-types';

describe('VmTableColumnTypes', () => {
  it('should create an instance', () => {
  //  expect(TABLE_COLUMN_TYPES).toBeTruthy();
  });
});
