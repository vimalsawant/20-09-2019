import { VmTableFilterOperator } from './vm-table-filter-operator';
import { VmTableColumn } from './vm-table-column';
import { FormBuilder, FormGroup,  Validators, FormControl } from '@angular/forms';
import { TABLE_FILTERS_PER_COLUMN_TYPE } from './catalog-table-filters-per-column-type';
import { Constants } from 'src/app/constants';

/**
 * Represents a single entry of a filter criterion by the user.
 * criterion: a single filter object.
 * criteria: a collection of many filter objects.
 */
export class VmTableFilterCriterion {
    operator: VmTableFilterOperator;
    filterValue: string;
    form: FormGroup;
    column: VmTableColumn;
    constructor( preExisting: VmTableFilterCriterion, fb: FormBuilder ) {
        if (fb) {
            if (preExisting) {
                this.form = fb.group({
                    operator: [preExisting.operator, Validators.required],
                    value: [preExisting.filterValue, Validators.required],
                    column: [preExisting.column, Validators.required]
                });
            } else {
                this.form = fb.group({
                    operator: [null, Validators.required],
                    value: [null, Validators.required],
                    column: [null, Validators.required]
                });
            }
            this.form.get('operator').valueChanges.subscribe((value: VmTableFilterOperator) => {
                const valueFormControl: FormControl = <FormControl> this.form.get('value');
                if (value && value.omitFilterValue) {
                    if ((!this.operator) || (!this.operator.omitFilterValue)) { // look at previous value to see if change needed.
                        valueFormControl.clearValidators();
                        valueFormControl.patchValue(null);
                    }
                } else {
                    if (this.operator && this.operator.omitFilterValue ) { // only change it if required.
                        valueFormControl.setValidators(Validators.required);
                    }
                }
                this.operator = value; // preserve previuos value for future reference
            });

            this.form.get('column').valueChanges.subscribe((value: VmTableColumn) => {
                const valueFormControl: FormControl = <FormControl> this.form.get('value');
                const operatorFormControl: FormControl = <FormControl> this.form.get('operator');
                operatorFormControl.patchValue(null);
                valueFormControl.setValidators(Validators.required);
                valueFormControl.patchValue(null);
            }) ;
        } else {
            // it means it is a VMTableFilter Criterion. it'll extract
            this.column = preExisting.form.get('column').value;
            this.operator = preExisting.form.get('operator').value;
            this.filterValue = preExisting.form.get('value').value;
        }
    }

    getColumnFilters(): VmTableFilterOperator[] {
        const column: VmTableColumn = this.form.get('column').value;
        if (column) {
            return TABLE_FILTERS_PER_COLUMN_TYPE[column.columnType];
        }
        return [];
    }

    requiredValue(): boolean {
        const operator: VmTableFilterOperator = this.form.get('operator').value;
        if (operator && operator.omitFilterValue) {
            return false;
        }
        return true; // for the sake of a consistent UI, expected behaviour.
    }

    toString(): string {
        let preResult =  this.column.headerName + ' ' +
        this.operator.displayName +
        (this.operator.omitFilterValue ?  '' : ' ' +
         (this.column.columnType !== 'OnePDLCheckbox' ? this.filterValue :
         (this.filterValue ? 'Yes' : 'No')));
        if (preResult && preResult.length > Constants.UI.maxChipLength) {
            preResult = preResult.substring(0, Constants.UI.maxChipLength) + '...';
        }
        return preResult;
    }
}


