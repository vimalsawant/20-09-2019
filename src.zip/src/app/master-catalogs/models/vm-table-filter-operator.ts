/**
 * Represents a filter operator
 */
export class VmTableFilterOperator {
    displayName: string;
    omitFilterValue ?= false; // typically a value is needed, except for 'isBlank' or 'is null' or something like that.
    // serverSideName: string - will be needed in case that we n
    // need to send a server side stringification in the query string or in a post.
    compare?: (columnValue: any, filterValue: any) => boolean;
}
