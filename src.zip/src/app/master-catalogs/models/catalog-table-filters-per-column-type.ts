import { TABLE_COLUMN_TYPES } from './catalog-table-column-types';
import { VmTableFilterOperator } from './vm-table-filter-operator';

const genericNumberFilters: VmTableFilterOperator[] = [
    {displayName: '=', compare: (x, y) => {
        const xNumber = parseFloat(x);
        const yNumber = parseFloat(y);
        if ( isNaN(xNumber) || isNaN(yNumber)) {
            return x === y;
        }
        return xNumber === yNumber;
    }},
    {displayName: '>', compare: (x, y) => x > y },
    {displayName: '<', compare: (x, y) => x < y },
    {displayName: '>=', compare: (x, y) => x >= y },
    {displayName: '<=', compare: (x, y) => x <= y },
    {displayName: '<>', compare: (x, y) => {
        const xNumber = parseFloat(x);
        const yNumber = parseFloat(y);
        if ( isNaN(xNumber) || isNaN(yNumber)) {
            return x !== y;
        }
        return xNumber !== yNumber;
    }} ];

const genericTextFilters: VmTableFilterOperator[] = [
    {displayName: 'Begins With', compare: (x: string, y: string) => x && x.startsWith(y)},
    {displayName: 'Contains' , compare: (x: string, y: string) => x && ( x.indexOf(y) >= 0) },
    {displayName: 'Ends With', compare: (x: string, y: string) => x && x.endsWith(y)},
    {displayName: 'Does Not Contain', compare: (x: string, y: string) => x && ( x.indexOf(y) < 0 ) },
    {displayName: 'Equal To', compare: (x: string, y: string) => x === y },
    {displayName: 'Not Equal To' , compare: (x: string, y: string) => x !== y },
    {displayName: 'Empty', omitFilterValue: true, compare: (x: string, y: string) => !(x) },
    {displayName: 'Not Empty', omitFilterValue: true, compare: (x: string, y: string) => !!(x) },
    {displayName: 'Less Than', compare: (x: string, y: string) => x < y},
    {displayName: 'Greater Than', compare: (x: string, y: string) => x > y},
    {displayName: 'Regex', compare: (x: string, y: string) => true} ];

const checkBoxFilters: VmTableFilterOperator[] = [
    {displayName: 'Equal To', compare: (x: string, y: string) => x === y },
    {displayName: 'Not Equal To' , compare: (x: string, y: string) => x !== y }
];

export const TABLE_FILTERS_PER_COLUMN_TYPE: { [propName: string]: VmTableFilterOperator []} = {
    'OnePDLNumber': [...genericNumberFilters],
    'OnePDLCurrency': [...genericNumberFilters],
    'OnePDLDate': [...genericNumberFilters],
    'OnePDLString': [...genericTextFilters],
    'OnePDLTextarea': [...genericTextFilters],
    'OnePDLList': [...genericTextFilters],
    'OnePDLCheckbox': checkBoxFilters
};
