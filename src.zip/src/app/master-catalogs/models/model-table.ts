import { VmTableColumn } from './vm-table-column';

/**
 * Configuration model for any kind of catalog.
 * DO NOT PUT ANY METHOD / Non JSON supported type as this will be
 * obtained from a remote location.
 */
export class ModelTable {
    title: string; // Title to display for the table
     // Configuration model for the columns.
     // as long as columns are not implementing behavior, we can reuse that object
     // otherwise, we will need to create a ModelTableColumn class.
    columns: VmTableColumn [];
    partNumberColumnName: string; // if present / not empty / not null, it will show the filter by part Number textarea.
    uniqueIdColumnName: string; // columnName to be handled as primary key  for edit purposes.
    getCatalogUri?: string; // uri to connect for getting this.
    hideNonRegisteredColumns?: boolean; // has to come and be true if we want to show ONLY the columns that come on the columns array.
    key?: string; // unused in the viewModel.  Used only for locating this object in config.json
    itemName?: string; // how to name a single item
    fileUploadFormats?: string; // comma separated allowed file extensions
    fileUploadUrl?: string;
    fileUploadMaxByteSize: number; // max size for file upload in bytes.
    getCatalogMethod?: string; // "PUT",  "GET" is default and  property unneeded., "POST", etc.
    getCatalogDefaultPayloadBase64?: string; // base 64 encoded JSON, example :  ewogICJzY0lkIjogIkJDTk9SIgp9
    saveItemUri?: string;
    // Edit mode will show a popup when adding and will show a button for editing when an entry is clicked / selected.
    enablePopupAddOrEdit?: boolean; // must be present and TRUE if we want to enable edit mode in the framework.
}
