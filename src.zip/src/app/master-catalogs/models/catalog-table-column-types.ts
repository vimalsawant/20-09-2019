/**Prefixing OnePDL to avoid type conflict/confusion with native Javascript / Typescript types. */
export type TABLE_COLUMN_TYPES =
     'OnePDLString'|
    'OnePDLNumber' |
    'OnePDLCurrency'|
    'OnePDLDate' |
    'OnePDLList' |  // for option multiple ( select or checkboxes or radio buttons)
    'OnePDLTextarea'| // for multiple  lines of text
    'OnePDLCheckbox'; // yes / no kind of data type
