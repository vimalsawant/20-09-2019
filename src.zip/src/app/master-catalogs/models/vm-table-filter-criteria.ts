import { VmTableFilterCriterion } from './vm-table-filter-criterion';
import { FormBuilder, FormGroup, FormArray, FormControl } from '@angular/forms';
import { Constants } from 'src/app/constants';

/**
 * Represents all the filter criteria
 * * criterion: a single filter object.
 * criteria: a collection of many filter objects.
 */

export class VmTableFilterCriteria {
    partNumber: string;
    tableFilterCriteria: VmTableFilterCriterion [];
    form: FormGroup;
    formArray: FormArray;
    /**
     * @param fb if this is not null it means we are in edit mode.
     * @param preExisting the preExisting validated object to copy to a new instance.
     * three posibilities:
     * fb  = null and preExisting != null : will create a new object with no reactive uderlying objects
     * fb != null and preExisting != null  will create a new reactive form with values of preExisting object.
     * fb != null and preExisting = null  will create a new reactive form with empty intializations values
     *  and add 1 empty obj. into the array.
     */
    constructor(private fb: FormBuilder, preExisting: VmTableFilterCriteria) {
        this.tableFilterCriteria = [];
        if (this.fb && !preExisting) {
            // means we are creating a new ngOnInit  empty model
            this.tableFilterCriteria.push(new VmTableFilterCriterion(null, this.fb));
            this.form = this.fb.group( {
                partNumber: null,
                criteria: this.fb.array([this.tableFilterCriteria[0].form])
            });
            this.formArray = <FormArray> this.form.get('criteria');
        }
        if (this.fb && preExisting) {
            // means we are creating an edit model out of a current valid applied filter model.
            if (preExisting.tableFilterCriteria.length) {
                preExisting.tableFilterCriteria.forEach(appliedCriterion =>
                    this.tableFilterCriteria.push(new VmTableFilterCriterion(appliedCriterion, this.fb)));
            } else { // criteria in edit mode got to show at least one empty element.
                this.tableFilterCriteria.push(new VmTableFilterCriterion(null, this.fb));
            }
            this.form = this.fb.group( {
                partNumber: preExisting.partNumber,
                criteria: this.fb.array([...this.tableFilterCriteria.map(x => x.form)])
            });
            this.formArray = <FormArray> this.form.get('criteria');
        }
        if (this.fb == null && preExisting ) {
            // means we are creating an appliedFIlter model out of an editModel.
            this.partNumber  = preExisting.form.get('partNumber').value;
            if (preExisting.hasNonEmptyValues()) {
                for (let i = 0; i < preExisting.tableFilterCriteria.length; i++ ) {
                    this.tableFilterCriteria.push(
                        new VmTableFilterCriterion(preExisting.tableFilterCriteria[i], null));
                }
            }
        }
    }

    addNewCriterion() {
        const criterion = new VmTableFilterCriterion( null, this.fb);
        this.formArray.push(criterion.form);
        this.tableFilterCriteria.push(criterion);
      }

      /**
       * in the future we will check if fb is null we need to make
       * a service call so the server updates the model.
       */
    clearPartNumber() {
        this.partNumber = null;
    }

     /**
   * Removes the underlying viewmodel ogject as well as the reactive form part of it.
   * If there is only one element in array, it wipes the values but won't remove that element.
   * */
  removeCriterion(i: number ) {
    if (this.fb == null) { // means this is an applied filter model
        this.tableFilterCriteria.splice(i, 1);
        return;
    }
    if (this.tableFilterCriteria.length > 1) {
        this.tableFilterCriteria.splice(i, 1);
        this.formArray.removeAt(i);
        this.form.markAsDirty();
    } else {
        const group: FormGroup = <FormGroup> this.formArray.get(i + '');
        for (const control in group.controls ) {
             if ( group.controls[control] instanceof FormControl ) {
                group.controls[control].patchValue(null);
             }
        }
    }
  }

   /**
   * For the recycle bin to hide if no values are there to empty - exclusively index zero.
   * method called also from other places.
   */
  hasNonEmptyValues(): boolean {
    const group: FormGroup = <FormGroup> this.formArray.get ('0');
    for (const control in group.controls) {
        if (group.controls[control] instanceof FormControl) {
            if (group.controls[control].value) {
                return true;
            }
        }
    }
    return false;
  }

  /**
   * Validates the filter form.
   * If it has not been changed, return false
   * If it is valid, then accept it. ( it means it must have filter values)
   * If it is not valid as per the valid property, there is still a chance for it to be valid
   * since they may want to filter only by part number   */
  validForApplying(): boolean {
    if (this.form.pristine) {
        return false;
    }
    if (this.form.valid) {
        return true;
    }
    // more complex validations must have a partNumber, must have the array with only one element and all empty values.
    const hasPartNumber = !!this.form.get('partNumber').value;
    if (hasPartNumber && this.formArray.length === 1 && !this.hasNonEmptyValues()) {
        return true;
    }
    return false;
  }

  isDirty(): boolean {
      return ((this.form && this.form.dirty) || this.tableFilterCriteria.length > 1 );
  }

   /**
   * When button clear all filters is clicked
   * We reset the filter form.
   * We also call the server and fetch a fresh set of records ( pending )
   */
  clearAll() {
    this.form.reset();
    this.tableFilterCriteria.forEach(c => {
        c.operator = null; // clear cached operators.
    });
    if (this.formArray.length > 1) {
        const intialLength = this.formArray.length;
      for (let i = intialLength - 1; i > 0; i--) {
          this.removeCriterion(i);
      }
    }
}

    partNumberCapped(): string {
        let result = this.partNumber;
        if (result && result.length > Constants.UI.maxChipLength) {
            result = result.substring(0, Constants.UI.maxChipLength) + '..';
        }
        return result;
    }



}
