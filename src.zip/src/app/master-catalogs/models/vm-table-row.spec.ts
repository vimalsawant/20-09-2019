import { VmTableRow } from './vm-table-row';

describe('VmTableRow', () => {
  it('should create an instance', () => {
    expect(VmTableRow).toBeTruthy();
  });

  it('should call patchValue', () => { });
  it('should call getRowValue', () => { });
  it('should call recalculateDirty', () => { });
  it('should call hasCellChanged', () => { });
  it('should call getBackendValue', () => { });
  it('should call undoAllChanges', () => { });
  it('should call commitChanges', () => { });
});
