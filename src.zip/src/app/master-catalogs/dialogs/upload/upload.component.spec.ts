import { async, ComponentFixture, TestBed, fakeAsync, tick, flush } from '@angular/core/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { UploadComponent } from './upload.component';
import { MatProgressBarModule,  MatButtonModule } from '@angular/material';
import { MatDialogModule } from '@angular/material/dialog';
import { DebugElement, NO_ERRORS_SCHEMA } from '@angular/core';
import { VmTable } from '../../models/vm-table';
import { CsvService } from '../../csv.service';

describe('UploadComponent', () => {
  let component: UploadComponent;
  let fixture: ComponentFixture<UploadComponent>;
  let debugElement: DebugElement;
  let csvService: CsvService;
  let vmtable: VmTable;

  beforeEach(async() => {
    TestBed.configureTestingModule({
      imports: [MatProgressBarModule, BrowserAnimationsModule, MatButtonModule, MatDialogModule],
      declarations: [ UploadComponent ],
      providers: [ csvService],
      schemas: [NO_ERRORS_SCHEMA],
    });
    csvService = TestBed.get(CsvService);
    vmtable = TestBed.get(VmTable);
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    debugElement = fixture.debugElement;
  });

  it('should create', () => {
     expect(component).toBeTruthy();
  });

  it('should call validateFile method', () => {
    component.errorMessage = 'false';
    expect(component.errorMessage).toBe( 'false' );
  });

  it('should call downloadClick', () => {
    component.downloadClick();
  });

  it('should call close', () => {
    component.close();
    fixture.detectChanges();
  });


  it('should call closeWindowRef when the dialog closing event triggered', (done) => {
    spyOn(component, 'closeWindowRef');
    component.close();
    fixture.detectChanges();
    tick();
    fixture.whenStable().then(() => {
      fixture.detectChanges();
      fixture.whenStable().then(() => {
        expect(component.closeWindowRef).toHaveBeenCalled();
        done();
      });
    });
  });

  it('should call selectedFile', () => {
    component.validFile = false;
    expect( component.validFile).toEqual( false );
    component.errorMessage = null;
    expect( component.errorMessage).toBeDefined( null );
  });
  it('should call validateFile method', () => {
    component.validFile = false;
    expect(component.validFile).toBeFalsy();
  });

  it('should call fileSize', () => {
  });

  it('should call uploadClick', fakeAsync(() => {
    component.uploadClick();
    flush();
    tick(101);
  }));
});
