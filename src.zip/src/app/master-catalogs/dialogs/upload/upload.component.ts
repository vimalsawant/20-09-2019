import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ConfirmDialogComponent } from '../../../layout/confirm-dialog/confirm-dialog.component';
import { MatDialog } from '@angular/material/dialog';
import { VmTable } from '../../models/vm-table';
import { CsvService } from '../../csv.service';
import { ConfirmDialogModel } from 'src/app/layout/confirm-dialog/confirm-dialog-model';


type uploadStatus = 'start' | 'selectionError' | 'uploading' | 'uploadError' | 'uploadSuccess';

@Component({
  selector: 'app-upload',
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.scss']
})
export class UploadComponent implements OnInit {

  // data expected from configuration:
  itemName = 'SampleItemName';
  fileFormatsAccept = '.sample, .sample2';
  maxFileSize = 100; // 50 MB in bytes
  uploadUri = '';
  private _status: uploadStatus = 'start';
  get status(): uploadStatus {
    return this._status;
  }
  /**
   * add initializers here please.
   */
  set status(n: uploadStatus) {
    if (n === 'uploading' ) {
      this.errorMessage = '';
      this.percentage = 0;
    }
    this._status = n;
  }

  errorMessage = '';
  validFile = false;
  selectedFileName = '';
  selectedFileSize = '';
  percentage = 0;
  intevalHandler: number;
  closeWindowRef: MatDialogRef<ConfirmDialogComponent> = null;

  constructor(private dialogRef: MatDialogRef<UploadComponent>,
    private dialogService: MatDialog,
    @Inject(MAT_DIALOG_DATA) public vmTable: VmTable,
    private csvService: CsvService ) {
      this.itemName = vmTable.tableModel.itemName;
      this.maxFileSize = vmTable.tableModel.fileUploadMaxByteSize;
      this.fileFormatsAccept = vmTable.tableModel.fileUploadFormats;
      this.uploadUri = vmTable.tableModel.fileUploadUrl;
     }

  ngOnInit() {
      // first successful test: CSV header
      // have to change file extension to csv:
       // const result = 'data:text/csv;charset=utf-8,' +
       // this.vmTable.getColumsForTemplate().join(',')
       // 
       // second successfull atempt.:
       // 
       // need to change extension to xls
      //  const ctx = {
      //   worksheet : this.vmTable.tableModel.itemName,
      //   table : '<table><tr><th>' + this.vmTable.getColumsForTemplate().join('</th><th>') + '</t></tr></table>'
      //   };
      //  const template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>';
      //   const result = 'data:application/vnd.ms-excel;base64,' +
      //   btoa(unescape(encodeURIComponent(template.replace(/{(\w+)}/g, (m, p) => ctx[p]))));
      //  this.templatePayload  = this.sanitizer.bypassSecurityTrustUrl(result);
  }

  downloadClick() {
        this.csvService.exportAsCsvFile([], this.vmTable.getColumsForTemplate(), 'template_' + this.vmTable.tableModel.itemName + '.csv' );
    }

  close() {
    if (this.status === 'uploading') {
      this.closeWindowRef = this.dialogService.open(ConfirmDialogComponent, {
        width: '350px',
        data: new ConfirmDialogModel('Upload in progress. Discard upload and close window?',
         [['Yes', true], ['No', false]])
      });
      this.closeWindowRef.afterClosed().subscribe( result => {
        if (result) {
          // Means user clicked 'Yes' and result is true.
          if (this.status === 'uploading') {
            this.dialogRef.close();
          }
        }
      });
    } else {
      this.dialogRef.close();
    }
  }

  selectedFile(files: FileList) {
      this.validFile = false;
      this.errorMessage = '';
     if (files && files.length > 0 ) {
        this.selectedFileName = files[0].name;
        this.validFile = this.validateFile(files[0]);
        if (this.validFile) {
          this.selectedFileSize = this.fileSize(files[0].size);
          this.status = 'start';
        } else {
          this.status = 'selectionError' ;
        }
     } else {
       this.selectedFileName = '';
     }
  }




  validateFile(file: File): boolean {
    let result = true;
    // validate file extension.
    if (this.fileFormatsAccept && this.fileFormatsAccept.length) {
      const extensions = this.fileFormatsAccept.split(',');
      if (!extensions.find(x => file.name.toLocaleLowerCase().endsWith(x.trim().toLocaleLowerCase()))) {
        this.errorMessage = 'Unsupported file format. Please choose another file';
        return false;
      }
    }
    // file size validation.
    if (this.maxFileSize && file.size > this.maxFileSize) {
      this.errorMessage = 'File exceeds size limit. Please choose another file';
      return false;
    }
    // empty file validation
    if (! file.size) {
      this.errorMessage = 'File appears to be empty. Please choose another file';
      return false;
    }
    return result;
  }

  fileSize(bytes: number): string {
    const exp = Math.log(bytes) / Math.log(1024) | 0;
    const result = (bytes / Math.pow(1024, exp)).toFixed(2);
    return result + ' ' + (exp === 0 ? 'bytes' : 'KMGTPEZY'[exp - 1] + 'B');
  }



  uploadClick() {
    this.status = 'uploading';
    this.intevalHandler = window.setInterval( x => {
      this.percentage++;
      if (this.percentage >= 100) {
        // this.error = 'An error ocurred while trying to upload.';
        this.status = 'uploadSuccess';
        if (this.closeWindowRef) {
          this.closeWindowRef.close();
          this.closeWindowRef = null;
        }
        clearInterval(this.intevalHandler);
      }
    }, 100);
  }
}
