import { TestBed, ComponentFixture, async } from '@angular/core/testing';
import { MatDialogModule,  MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { EditUserComponent } from './edit-user.component';
import { VmUserServiceContract } from './models/vm-user-service-contract';
import { VmTable } from '../../models/vm-table';
import { VmTableRow } from '../../models/vm-table-row';

describe('EditComponent', () => {
  let component: EditUserComponent;
  let fixture: ComponentFixture<EditUserComponent>;

  const dialogMock = {
    close: () => { }
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [  MatDialogRef, MatDialogModule ],
      declarations: [ EditUserComponent, VmTable, VmTableRow ],
      providers: [
        { provide: VmUserServiceContract, useValue: {}},
         {provide: MatDialogRef, useValue: dialogMock},
         {provide: MAT_DIALOG_DATA, useValue: []}
      ]
    });
    fixture = TestBed.createComponent(EditUserComponent);
    component = fixture.componentInstance;
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditUserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should run ngOnInit()', async () => {
    expect(component.ngOnInit).toHaveBeenCalled();
  });

  it('should call the function to close', async(() => {
    component.close();
   // expect(component.dialogRef.close).toHaveBeenCalled();
  }));

  it('should have call save', async(() => {
    component.save();
    expect(component.save).toHaveBeenCalled();
  }));
});
