
/**
 * Represents a binding between a user and one or more service contracts
 * We can update model to match backend service in the future.
 */
export class ModelUserServiceContract {
    UserID: string;
    ServiceContractID: string; // comma separated id of the contracts.
    FirstName: string;
    LastName: string;
    Email: string;
    UserType: string;
    Active: string; // Yes or No.
    CreatedBy: string;
    CreatedDate: string;
    UpdatedBy: string;
    UpdatedDate: string;
}
