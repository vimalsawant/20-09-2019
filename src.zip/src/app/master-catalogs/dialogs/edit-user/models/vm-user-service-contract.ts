import { ModelUserServiceContract } from './model-user-service-contract';
import { FormBuilder, FormGroup, FormArray, FormControl, Validators } from '@angular/forms';
import { ActiveDescendantKeyManager } from '@angular/cdk/a11y';

export class VmUserServiceContract {
    form: FormGroup;
    errors: any = {};  // current errors.

    /**
     * @param model if it is null, we'll assume it's 'Add New' functionality.
     * @param fb the form builder service provided through DI in the parent component
     */
    constructor(public model: ModelUserServiceContract, private fb: FormBuilder) {
        this.form = this.fb.group({
            UserID: [this.model && this.model.UserID, Validators.required],
            ServiceContracts: [this.model && this.convertUserServiceContractToArray(this.model.ServiceContractID), Validators.required],
            FirstName: fb.control({ value: this.model && this.model.FirstName, disabled: true}),
            LastName: fb.control({ value: this.model && this.model.LastName, disabled: true}),
            Active: [ !(this.model) || this.model.Active === 'Yes']
        }, {updateOn: 'blur'});

        this.form.valueChanges.subscribe(x => {
            this.errors = {};
            for (const abstractControl of Object.keys(this.form.controls)) {
                const formControl: FormControl = <FormControl>this.form.get(abstractControl);
                this.errors[abstractControl] = '';
                if (formControl && formControl.dirty && !formControl.valid) {
                    this.errors[abstractControl] = 'This field is required';
                }
            }
        });
    }


    convertUserServiceContractToArray(commaSeparated: string): string [] {
        if (!commaSeparated) {
            return [];
        }
        const untrimmed = commaSeparated.split(',');
        const trimmedArr: string[] = [];
        untrimmed.forEach(x => trimmedArr.push(x.trim()));
        return trimmedArr;
    }
}
