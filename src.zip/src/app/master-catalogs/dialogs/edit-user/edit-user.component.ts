import { Component, OnInit, Inject } from '@angular/core';
import { VmTableRow } from '../../models/vm-table-row';
import { VmTable } from '../../models/vm-table';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { VmUserServiceContract } from './models/vm-user-service-contract';
import { FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-edit',
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.scss']
})
export class EditUserComponent implements OnInit {

    edit: 'Edit' | 'New' = 'New';
    itemName = '';
    saveError = '';
    // pending to connect the below to the actual catalog of service contracts
    serviceContractCatalog = ['SC1', 'SC2', 'SC3', 'SC4', 'SC5'];
    viewModel: VmUserServiceContract;


  constructor(
    private dialogRef: MatDialogRef<EditUserComponent>,
      @Inject(MAT_DIALOG_DATA) public vmParameters: [VmTable, VmTableRow],
      private fb: FormBuilder) {
      this.edit = !!(vmParameters[1]) ? 'Edit' : 'New';
      this.itemName = vmParameters[0].tableModel.itemName;
   }

  ngOnInit() {
      this.viewModel = new VmUserServiceContract((this.vmParameters[1] && this.vmParameters[1].originalData), this.fb);
      this.viewModel.form.valueChanges.subscribe( x => this.saveError = '');
  }

  close() {
      this.dialogRef.close();
  }

  save() {
      if (this.viewModel.form.valid) {
          this.close();
      } else {
          this.saveError = 'Unable to save. Please verify the above fields';
      }
  }

}
