import { TestBed, async } from '@angular/core/testing';
import {HttpClientModule} from '@angular/common/http';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { DataServiceParameters } from 'src/app/models/data-service-parameters';
import { SpmOrchestrationService } from './spm-orchestration.service';
import { DataService } from 'src/app/services/data.service';
import { ServiceContractConfigService } from 'src/app/services/service-contract-config.service';

describe('SpmOrchestrationService', () => {
  let service: SpmOrchestrationService;
  let dataService: DataService;
  let serviceContractConfigService: ServiceContractConfigService;

  beforeEach(() => {
      TestBed.configureTestingModule({
          imports: [HttpClientModule],
          providers: [DataService, DataServiceParameters, SpmOrchestrationService, ServiceContractConfigService
             ],
          schemas: [ NO_ERRORS_SCHEMA ],
      });
      service = TestBed.get(SpmOrchestrationService);
      dataService = TestBed.get(DataService);
      serviceContractConfigService = TestBed.get(ServiceContractConfigService);
  });

  it('should be created', () => {
    // tslint:disable-next-line: no-shadowed-variable
    const service: SpmOrchestrationService = TestBed.get(SpmOrchestrationService);
    expect(service).toBeTruthy();
  });

  it('should be created dataservice', () => {
    const dataservice: DataService = TestBed.get(DataService);
    expect(dataservice).toBeTruthy();
  });

  it('should be created serviceContractConfigService', () => {
    // tslint:disable-next-line: no-shadowed-variable
    const serviceContractConfigService: ServiceContractConfigService = TestBed.get(ServiceContractConfigService);
    expect(serviceContractConfigService).toBeDefined();
  });

  it('Should require trigger data', async(() => {
    expect(service.trigger).toBeDefined();
  }));

});
