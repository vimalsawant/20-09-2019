import { Injectable } from '@angular/core';
import { DataService } from 'src/app/services/data.service';
import { of, Observable, forkJoin } from 'rxjs';
import { Constants } from 'src/app/constants';
import { DataServiceParameters } from 'src/app/models/data-service-parameters';
import { switchMap, map } from 'rxjs/operators';
import { ServiceContractConfigService } from 'src/app/services/service-contract-config.service';
import { ModelSpmOrchestratorTriggerRequest } from '../models/model-spm-orchestrator-trigger-request';
import { ModelSpmOrchestratorTriggerResponse } from '../models/model-spm-orchestrator-trigger-response';

@Injectable({
  providedIn: 'root'
})
export class SpmOrchestrationService {

  constructor(private dataService: DataService, private serviceContractConfigService: ServiceContractConfigService) { }

    /**
     * Triggers the service for the given transactions
     * Caller is responsible of error handling.
     * @param transactions string array that come from the 'name' property of the transactions.
     */
    trigger(transactions: string[]): Observable<number> {
        const scId$ = this.serviceContractConfigService.getCurrentScId();
        const parameters$ =  this.dataService.getConfigSection<DataServiceParameters>(Constants.jsonConfigSectionOrchestrationService);
        return forkJoin(scId$, parameters$).pipe(
            switchMap(results => this.dataService.invoke<ModelSpmOrchestratorTriggerResponse>(results[1].getCatalogUri,
                results[1].getCatalogMethod, new ModelSpmOrchestratorTriggerRequest(results[0], transactions))),
            map(response => response.downloadId)
        );
    }
}
