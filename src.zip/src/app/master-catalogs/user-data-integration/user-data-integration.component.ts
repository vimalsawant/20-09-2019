import { Component, OnInit } from '@angular/core';
import { MatDialog, MatSnackBar } from '@angular/material';

import { VmServiceContractConfigTransaction } from './models/vm-service-contract-config-transaction';
import { ServiceContractConfigService } from '../../services/service-contract-config.service';
import { VmServiceContractConfig } from './models/vm-service-contract-config';
import { ConfirmDialogModel } from 'src/app/layout/confirm-dialog/confirm-dialog-model';
import { ConfirmDialogComponent } from '../../layout/confirm-dialog/confirm-dialog.component';
import { SpmOrchestrationService } from './services/spm-orchestration.service';
import { Constants } from '../../constants';

@Component({
  selector: 'app-user-data-integration',
  templateUrl: './user-data-integration.component.html',
  styleUrls: ['./user-data-integration.component.scss']
})
export class UserDataIntegrationComponent implements OnInit {
  pageTitle = 'Run Data Integration';
  lblSelectAll = 'Select All';
  submitting = false;

  public allSelected = false;
  public indeterminate = false;
  private vmServiceContractConfig:  VmServiceContractConfig;
  transactions: VmServiceContractConfigTransaction[];
  loading = true;


  rundataCheckboxes(userData: VmServiceContractConfigTransaction, event) {
    userData.checked = event.checked;
    const totalSelected = this.transactions.filter(i => i.checked).length;
    if (totalSelected === 0) {
      this.allSelected = false;
      this.indeterminate = false;
    } else if (totalSelected > 0 && totalSelected < this.transactions.length) {
      this.allSelected = false;
      this.indeterminate = true;
    } else if (totalSelected === this.transactions.length) {
      this.allSelected = true;
      this.indeterminate = false;
    }
  }

  toggleSelectAll(event) {
    this.allSelected = event.checked;
    this.indeterminate = event.isChecked;
    this.transactions.forEach(transaction => {
        transaction.checked = event.checked;
    });
  }

  submit() {
    const transactionNames = this.transactions.filter(t => t.checked).map(u => u.model.name);
    this.submitting = true;
    this.spmOrchestrationService.trigger(transactionNames).subscribe(
        downloadId => {
            this.snackBar.open('Request #' + downloadId + ' Submitted', 'Close', Constants.UI.snackBarDuration);
            this.submitting = false;
        },
        e => this.dialogService.open(ConfirmDialogComponent, {
            width: '350px',
            data: new ConfirmDialogModel('Error: ' + e)
            }).afterClosed().subscribe(() => this.submitting = false));
  }

  constructor(public serviceContractConfigService: ServiceContractConfigService,
    private dialogService: MatDialog,
    private spmOrchestrationService: SpmOrchestrationService,
    private snackBar: MatSnackBar) {
   }

  ngOnInit() {
      this.vmServiceContractConfig = new VmServiceContractConfig(this.serviceContractConfigService);
      this.vmServiceContractConfig.getCurrentTransactions()
        .subscribe(result => this.transactions = result,
            e => this.dialogService.open(ConfirmDialogComponent, {
                width: '350px',
                data: new ConfirmDialogModel('Error: ' + e.message ? e.message : e)
              }).afterClosed().subscribe(() => this.loading = false),
              () => this.loading = false
              );
   }
}
