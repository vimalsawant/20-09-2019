import { async, ComponentFixture, TestBed, fakeAsync } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement, inject } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';

import { ConfirmDialogComponent } from '../../layout/confirm-dialog/confirm-dialog.component';
import { UserDataIntegrationComponent } from './user-data-integration.component';
import { ServiceContractConfigService } from '../../services/service-contract-config.service';
import { VmServiceContractConfigTransaction } from './models/vm-service-contract-config-transaction';
import { VmServiceContractConfig } from './models/vm-service-contract-config';
import { SpmOrchestrationService } from './services/spm-orchestration.service';
import {MatSnackBar} from '@angular/material/snack-bar';
import { MatDialog } from '@angular/material/dialog';


describe('UserDataIntegrationComponent', () => {
  let component: UserDataIntegrationComponent;
  let fixture: ComponentFixture<UserDataIntegrationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientModule, MatDialog, MatSnackBar],
      declarations: [UserDataIntegrationComponent, ConfirmDialogComponent],
      providers: [
        { provide: MatSnackBar, useValue: {} },
        { provide: MatDialog, useValue: {} },
        { provide: SpmOrchestrationService, useValue: {} },
        { provide: ServiceContractConfigService, useValue: {} },
        { provide: VmServiceContractConfig, useValue: {} },
        { provide: VmServiceContractConfigTransaction, useValue: {} },
      ],
    })
      .compileComponents();

  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserDataIntegrationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call rundataCheckboxes', () => {
    expect(component.rundataCheckboxes).toBeFalsy();
    component.allSelected = false;
    expect(component.allSelected).toBe(false);
    component.indeterminate = false;
    expect(component.indeterminate).toBe(false);
    component.loading = true;
    expect(component.loading).toBe(true);
  });

  it('should create toggleSelectAll ', async(() => {
    spyOn(component, 'toggleSelectAll');
    const checkbox = fixture.debugElement.nativeElement.querySelector('mat-checkbox label');
    checkbox.click();
    component.allSelected = false;
    expect(component.allSelected).toBe(false);
    component.indeterminate = false;
    expect(component.indeterminate).toBe(false);
  }));

  it('should call submit', () => {
    component.submit();
    expect(component.submit).toHaveBeenCalled();
  });

  it('should call ngOnInit', () => {
    component.ngOnInit();
    expect(component.ngOnInit).toHaveBeenCalled();
    component.loading = true;
    expect(component.loading).toBe(true);
  });

});
