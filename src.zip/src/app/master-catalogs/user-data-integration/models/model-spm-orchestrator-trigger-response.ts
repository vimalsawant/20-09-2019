export class ModelSpmOrchestratorTriggerResponse {
    downloadId: number;
    scId: string;
    transactionTypes: string [];
}
