import { ServiceContractConfigTransactionModel } from '../../../models/service-contract-config-transaction-model';

export class VmServiceContractConfigTransaction {
    constructor(public model: ServiceContractConfigTransactionModel,
                public checked = false) {}
}
