import { ModelSpmOrchestratorTriggerRequest } from './model-spm-orchestrator-trigger-request';

describe('ModelSpmOrchestratorTrigger', () => {
  it('should create an instance', () => {
    expect(ModelSpmOrchestratorTriggerRequest).toBeTruthy();
  });
});
