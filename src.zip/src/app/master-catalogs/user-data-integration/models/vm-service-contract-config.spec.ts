import { TestBed, async, ComponentFixture } from '@angular/core/testing';
import { ServiceContractConfigService } from 'src/app/services/service-contract-config.service';
import { VmServiceContractConfig } from './vm-service-contract-config';

describe('VmServiceContractConfig', () => {
  let test: VmServiceContractConfig;
  let fixture: ComponentFixture<VmServiceContractConfig>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VmServiceContractConfig , ServiceContractConfigService ],
      imports: [],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VmServiceContractConfig);
    test = TestBed.get(VmServiceContractConfig);
    test = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create an instance', () => {
    expect(VmServiceContractConfig).toBeTruthy();
  });

  it('should call getCurrentTransactions', () => {
  });

});
