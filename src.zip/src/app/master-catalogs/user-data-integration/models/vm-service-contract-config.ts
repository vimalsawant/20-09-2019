import { VmServiceContractConfigTransaction } from './vm-service-contract-config-transaction';
import { ServiceContractConfigService } from '../../../services/service-contract-config.service';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
export class VmServiceContractConfig {

    constructor(public serviceContractConfigService: ServiceContractConfigService) {}

    public getCurrentTransactions (): Observable<VmServiceContractConfigTransaction []> {
        return this.serviceContractConfigService.getServiceContractConfig().pipe(
            map(wholeConfig => wholeConfig[0].transactions ?
                wholeConfig[0].transactions.map(x => new VmServiceContractConfigTransaction(x)).sort(
                    (a, b) => a.model.label.localeCompare(b.model.label)
                )
                : [])
        );
    }
}
