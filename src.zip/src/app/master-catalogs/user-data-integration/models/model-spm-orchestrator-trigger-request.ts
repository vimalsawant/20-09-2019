export class ModelSpmOrchestratorTriggerRequest {
    constructor(public scId: string, public transactionTypes: string[]) {}
}
