import { VmServiceContractConfigTransaction } from './vm-service-contract-config-transaction';

describe('VmServiceContractConfigTransaction', () => {
  it('should create an instance', () => {
    expect(VmServiceContractConfigTransaction).toBeTruthy();
  });
});
