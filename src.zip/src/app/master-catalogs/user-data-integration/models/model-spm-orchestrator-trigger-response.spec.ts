import { ModelSpmOrchestratorTriggerResponse } from './model-spm-orchestrator-trigger-response';

describe('ModelSpmOrchestratorTriggerResponse', () => {
  it('should create an instance', () => {
    expect(ModelSpmOrchestratorTriggerResponse).toBeTruthy();
  });
});
