import { Component } from '@angular/core';
import { LoginService } from './login/login.service';
import { Router, NavigationEnd, NavigationStart, NavigationError } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
    title = 'OnePDL';
    cursorStyle = {};
  constructor(public authService: LoginService, private router: Router) {
      this.router.events.subscribe(event => {
        if (event instanceof NavigationStart) {
            this.cursorStyle['cursor'] = 'progress';
        }
        if (event instanceof NavigationEnd || event instanceof NavigationError) {
            this.cursorStyle['cursor'] = 'default';
        }
      });
  }
}
