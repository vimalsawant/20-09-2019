import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';

const routes: Routes = [
  {path: '', component: LoginComponent},
  // we may override loading actions by adding an /actions route before.
  // as we know it will stop matching at the first occurrence.
  {path: 'actions', loadChildren: () => import('./master-catalogs/master-catalogs.module').then(
    mod => mod.MasterCatalogsModule)
    },
  {path: 'catalogs',
    loadChildren: () => import('./master-catalogs/master-catalogs.module').then(
      mod => mod.MasterCatalogsModule)
    },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
