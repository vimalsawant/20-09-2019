import { Component, OnInit, Input, Renderer2 } from '@angular/core';
import { UiService } from 'src/app/services/ui.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.scss']
})
export class MenuComponent implements OnInit {

  modulesList: Array<any>;
  enteredButton = false;
  isMatMenuOpen = false;
  isMatMenu2Open = false;
  prevButtonTrigger;
  buttonEnterTimeout: number = null;
  set showResponsive(x: boolean) {
    if (x) {
      this.resetResponsiveMenu();
    }
    this._showResponsive = x;
  }
  get showResponsive(): boolean {
    return this._showResponsive;
  }
  private _showResponsive = false;

  set responsive(x: boolean) {
    if (x) {
      this.showResponsive = false;
    }
    this._responsive = x;
  }
  get responsive(): boolean {
    return this._responsive;
  }
  private _responsive = false;


  public get showDataMaintenance(): boolean {
    return this._showDataMaintenance;
  }
  public set showDataMaintenance(showDatMaintenance: boolean) {
    this._showDataMaintenance = showDatMaintenance;
  }
  private _showDataMaintenance = false;

  public get showMasterData(): boolean {
    return this._showMasterData;
  }
  public set showMasterData(showMasterData: boolean) {
    this._showMasterData = showMasterData;
    if (this._showMasterData) {
      this._showInventoryPositions = false;
      this._showIOOverrides = false;
      this._showForecasting = false;
    }
  }
  private _showMasterData = false;

  public get showForecasting(): boolean {
    return this._showForecasting;
  }
  public set showForecasting(showForecasting: boolean) {
    this._showForecasting = showForecasting;
    if (this._showForecasting) {
      this._showInventoryPositions = false;
      this._showIOOverrides = false;
      this._showMasterData = false;
    }
  }
  private _showForecasting = false;

  public get showIOOverrides(): boolean {
    return this._showIOOverrides;
  }
  public set showIOOverrides(showIOOverrides: boolean) {
    this._showIOOverrides = showIOOverrides;
    if (showIOOverrides) {
      this._showInventoryPositions = false;
      this._showForecasting = false;
      this._showMasterData = false;
    }
  }
  private _showIOOverrides = false;

  public get showInventoryPositions(): boolean {
    return this._showInventoryPositions;
  }
  public set showInventoryPositions(showInventoryPositions: boolean) {
    this._showInventoryPositions = showInventoryPositions;
    if (showInventoryPositions) {
      this._showIOOverrides = false;
      this._showForecasting = false;
      this._showMasterData = false;
    }
  }
  private _showInventoryPositions = false;

  public get showActions(): boolean {
      return this._showActions;
  }

  public set showActions(showActions: boolean) {
      this._showActions = showActions;
  }
  private _showActions = false;

  public get showAdmin(): boolean {
    return this._showAdmin;
    }

    public set showAdmin(showAdmin: boolean) {
        this._showAdmin = showAdmin;
    }
    private _showAdmin = false;


  constructor(private ren: Renderer2, private uiService: UiService, private router: Router) {
    this.uiService.isResponsiveMode$.subscribe(x => this.responsive = x);
  }

  /**
   * Used in responsive mode whenever the trigger is clicked.
   */
  public responsiveTriggerClicked() {
    this.showResponsive = !this.showResponsive;
  }

  /**
   * Reset menu to initial state.
   */
  private resetResponsiveMenu() {
    this.showDataMaintenance = this.showForecasting = this.showIOOverrides = this.showInventoryPositions = this.showMasterData = false;
    this.showActions = false;
    this.showAdmin = false;
  }

  private responsiveClick(url: string) {
    this.showResponsive = false;
    this.router.navigateByUrl(url);
  }

  ngOnInit() {
  }
}
