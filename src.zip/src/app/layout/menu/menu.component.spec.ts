import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { BrowserModule, By } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatButtonModule, MatFormFieldModule, MatInputModule, MatToolbarModule,
   MatCardModule, MatSelectModule, MatProgressSpinnerModule, MatDialogModule, MatMenuModule } from '@angular/material';
import {RouterTestingModule} from '@angular/router/testing';
import { MenuComponent } from './menu.component';

describe('MenuComponent', () => {
  let component: MenuComponent;
  let fixture: ComponentFixture<MenuComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MenuComponent ],
      imports: [
        MatMenuModule,
        BrowserModule,
        BrowserAnimationsModule,
        MatButtonModule,
        MatFormFieldModule,
        MatInputModule,
        MatToolbarModule,
        MatCardModule,
        MatSelectModule,
        MatProgressSpinnerModule,
        MatDialogModule,
        RouterTestingModule
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(MenuComponent).toBeTruthy();
  });

  it('should call get and set show data maintenenace method', () => {
    component.showDataMaintenance = true;
    const spy = spyOnProperty(component, 'showDataMaintenance', 'get').and.callThrough();
    expect(component.showDataMaintenance).toBe(true);
    expect(spy).toHaveBeenCalled();
  });

  it('should call get and set show master data method', () => {
    component.showMasterData = true;
    const spy = spyOnProperty(component, 'showMasterData', 'get').and.callThrough();
    expect(component.showMasterData).toBe(true);
    expect(spy).toHaveBeenCalled();

    // to cover the false branch
    component.showMasterData = false;
    expect(component.showMasterData).toBe(false);
    expect(spy).toHaveBeenCalled();

  });

  it('should call get and set show forecasting method', () => {
    component.showForecasting = true;
    const spy = spyOnProperty(component, 'showForecasting', 'get').and.callThrough();
    expect(component.showForecasting).toBe(true);
    expect(spy).toHaveBeenCalled();

    // to cover the false branch
    component.showForecasting = false;
    expect(component.showForecasting).toBe(false);
    expect(spy).toHaveBeenCalled();
  });


  it('should call get and set show IO overrides method', () => {
    component.showIOOverrides = true;
    const spy = spyOnProperty(component, 'showIOOverrides', 'get').and.callThrough();
    expect(component.showIOOverrides).toBe(true);
    expect(spy).toHaveBeenCalled();

    // to cover the false branch
    component.showIOOverrides = false;
    expect(component.showIOOverrides).toBe(false);
    expect(spy).toHaveBeenCalled();

  });


  it('should call get and set show inventory positions method', () => {
    component.showInventoryPositions = true;
    const spy = spyOnProperty(component, 'showInventoryPositions', 'get').and.callThrough();
    expect(component.showInventoryPositions).toBe(true);
    expect(spy).toHaveBeenCalled();

    // to cover the false branch

    component.showInventoryPositions = false;
    expect(component.showInventoryPositions).toBe(false);
    expect(spy).toHaveBeenCalled();
  });

  it('should used in responsiveTriggerClicked responsive mode whenever the trigger is clicked', () => {
    component.showResponsive = true;
    expect(component.showResponsive).toBe(true);
  });

  it('should have call method resetResponsiveMenu', () => {
    component.showDataMaintenance = false;
    expect(component.showDataMaintenance).toBe(false);
    component.showForecasting = false;
    expect(component.showForecasting).toBe(false);
    component.showIOOverrides = false;
    expect(component.showIOOverrides).toBe(false);
    component.showInventoryPositions = false;
    expect(component.showInventoryPositions).toBe(false);
    component.showMasterData = false;
    expect(component.showMasterData).toBe(false);
    component.showActions = false;
    expect(component.showActions).toBe(false);

  });

  it('should have call responsiveClick', () => {
    component.showResponsive = false;
    expect(component.showResponsive).toBe(false);

  });

  it('should ngOnInit', () => {
    component.ngOnInit();
  });
});

