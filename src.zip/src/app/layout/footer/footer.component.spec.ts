import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { FooterComponent } from './footer.component';
import { LoginService } from '../../login/login.service';
import { DataService } from 'src/app/services/data.service';
import { HttpClientModule } from '@angular/common/http';

describe('AppFooterComponent Test', () => {
  let component: FooterComponent;
  let fixture: ComponentFixture<FooterComponent>;
  let authService: LoginService;
  let dataServie: DataService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientModule],
      declarations: [ FooterComponent ],
      providers: [LoginService, DataService]
    });
    authService = TestBed.get(LoginService);
    dataServie = TestBed.get(DataService);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FooterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create footer component', () => {
    expect(component).toBeTruthy();
  });

  it('should load Copyright information in footer', () => {
    const compiled = fixture.debugElement.query(By.css('#Copyright'));
    expect(compiled.nativeElement.textContent.trim()).toBe('Copyright © ' + component.currentYear + ' Boeing.');
  });

});
