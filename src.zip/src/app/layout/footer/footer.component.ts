import { Component, OnInit } from '@angular/core';
import { LoginService } from '../../login/login.service';
import { DataService } from 'src/app/services/data.service';
import { Constants } from 'src/app/constants';


@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss']
})
export class FooterComponent implements OnInit {

  currentYear: number = new Date().getFullYear();
  appVersion = '1.56.3';
  lastUpdatedDate = '01/01/2001';
  constructor(public authService: LoginService, private dataServie: DataService) { }

  ngOnInit() {
      this.dataServie.getConfigSection<string>(Constants.jsonCOnfigSectionlastUpdateApplication).subscribe( x => {
          try {
                if (x && x.indexOf('-') >= 0) {
                    const dateParts = x.split('-');
                    const dateFromConfig = new Date(parseInt(dateParts[2], 10),
                     parseInt(dateParts[0], 10) - 1 , parseInt(dateParts[1], 10));
                    this.lastUpdatedDate = dateFromConfig.toLocaleDateString();
                }
            } catch (x) {}
      });
  }

}
