import { Component, OnInit, Input } from '@angular/core';
import {User} from 'src/app/models/user';
import { headersToString } from 'selenium-webdriver/http';

@Component({
  selector: 'app-identity',
  templateUrl: './identity.component.html',
  styleUrls: ['./identity.component.scss']
})
export class IdentityComponent implements OnInit {

  @Input()
  public identity: User;

  constructor() {
    this.identity = { bemsId: '3256744', displayName: 'Herdt, Dean R' };
   }

  ngOnInit() {

  }

}
