export class ConfirmDialogModel {


    /**
     * By default shows  'Accept' button only. (if only param provided is message)
     * Otherwise please provide button name and button value pair array
     * @param message string message to display
     * @param buttonOptions button message and button value pairs OR single button text string...  First button will be defaulted / focused.
     * @param showCloseIcon whether to show an X on the top right corner of the confirm dialog.
     */
    constructor(public message: string,
        public buttonOptions?: [string, any][] | string,
        public showCloseIcon =  false  ) {
        if (typeof buttonOptions === 'string' && buttonOptions) {
            this.buttonOptions = [[buttonOptions, true]];
        }
        if (!this.buttonOptions) {
            this.buttonOptions = [['Accept', true]];
        }
    }
}
