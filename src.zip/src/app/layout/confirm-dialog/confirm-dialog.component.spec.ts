import { async, ComponentFixture, TestBed, fakeAsync } from '@angular/core/testing';
import { ConfirmDialogComponent } from './confirm-dialog.component';
import { Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatButtonModule} from '@angular/material';
import { MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { ConfirmDialogModel } from './confirm-dialog-model';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';

describe('ConfirmDialogComponent', () => {
  let component: ConfirmDialogComponent;
  let fixture: ComponentFixture<ConfirmDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [Inject, MatDialogRef,  MAT_DIALOG_DATA, MatButtonModule, MatDialogModule],
      declarations: [ConfirmDialogComponent, ConfirmDialogModel],
      providers: [
        { provide: MatDialogRef, useValue: {} },
        { provide: MAT_DIALOG_DATA, useValue: [] }
      ]
    });
    TestBed.overrideModule(BrowserDynamicTestingModule, {
      set: {
        entryComponents: [ConfirmDialogComponent]
      }
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfirmDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });


  it('should call the function to close the dialog', () => {
    component.close();
    expect(component.dialogRef.close).toHaveBeenCalled();
  });

});
