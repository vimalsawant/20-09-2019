import { ConfirmDialogModel } from './confirm-dialog-model';

describe('ConfirmDialogModel', () => {

  it('should create an instance', () => {
    expect(ConfirmDialogModel).toBeTruthy();
  });

  it('should call buttonOptions', () => {
  //   ConfirmDialogModel.buttonOptions = true;
  //   expect(ConfirmDialogModel.buttonOptions).toBeDefined();
  });

  it('should call showCloseIcon', () => {
  //   ConfirmDialogModel.showCloseIcon = false;
  //   expect(ConfirmDialogModel.showCloseIcon).toBeDefined();
  });
});
