import { Component, OnInit, ViewChild } from '@angular/core';
import { LoginService } from '../../login/login.service';
import { MenuComponent } from '../menu/menu.component';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  @ViewChild(MenuComponent) menu: MenuComponent;

  constructor(public authService: LoginService) {
   }

  ngOnInit() {
  }

  responsiveTriggerClicked() {
    this.menu.responsiveTriggerClicked();
  }

}
