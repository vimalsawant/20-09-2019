import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HeaderComponent } from './header.component';
import { AppComponent } from 'src/app/app.component';
import { FooterComponent } from '../footer/footer.component';
import { LoginComponent } from 'src/app/login/login.component';
import { MenuComponent } from '../menu/menu.component';
import { IdentityComponent } from '../identity/identity.component';
import { BrowserModule, By } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatMenuModule } from '@angular/material/menu';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatCardModule } from '@angular/material/card';
import { MatSelectModule } from '@angular/material/select';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatDialogModule } from '@angular/material/dialog';
import { AppRoutingModule } from 'src/app/app-routing.module';
import { DebugElement } from '@angular/core';
import { LoginService } from 'src/app/login/login.service';
import { MatPaginatorModule } from '@angular/material';
import { MatTableModule } from '@angular/material';

describe('HeaderComponent Test', () => {
  let component: HeaderComponent;
  let fixture: ComponentFixture<HeaderComponent>;
  let compiled: DebugElement;

  const MockLoginService = {
    isLoggedIn : true
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        MatTableModule,
        MatPaginatorModule,
        BrowserModule,
        BrowserAnimationsModule,
        MatMenuModule,
        MatButtonModule,
        MatFormFieldModule,
        MatInputModule,
        MatToolbarModule,
        MatCardModule,
        MatSelectModule,
        MatProgressSpinnerModule,
        MatDialogModule,
        AppRoutingModule
      ],
      declarations: [
        AppComponent,
        FooterComponent,
        HeaderComponent,
        LoginComponent,
        MenuComponent,
        IdentityComponent
    ],
    providers: [
      {provide: LoginService, useValue: MockLoginService}
    ]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create header component ', () => {
    expect(component).toBeTruthy();
  });

  it('should have headertext as OnePDL ', () => {
    const compiled = fixture.debugElement.query(By.css('.areaAppName'));
    expect(compiled.nativeElement.textContent.trim()).toBe('OnePDL');
  });

  it('should load menu when isLoggedIn is true', () => {
    let compiled = null;
    fixture = TestBed.createComponent(HeaderComponent);
    component = fixture.componentInstance;
    expect(fixture.debugElement.query(By.css('.hideNav > nav:nth-child(1) > div:nth-child(1)'))).toBeNull();
    fixture.detectChanges();
    expect(fixture.debugElement.query(By.css('.hideNav > nav:nth-child(1) > div:nth-child(1)'))).toBeDefined();
    expect(fixture.debugElement.query(By.css('.hideNav > nav:nth-child(1) > div:nth-child(1)')).nativeElement.textContent.trim()).toEqual('Admin');
  });

  it('should load identity when isLoggedIn is true', () => {
    var compiled = null;
    fixture = TestBed.createComponent(HeaderComponent);
    component = fixture.componentInstance;
    expect(fixture.debugElement.query(By.css('.areaIdentity'))).toBeNull();
    expect(fixture.debugElement.query(By.css('.name'))).toBeNull();
    fixture.detectChanges();
    expect(fixture.debugElement.query(By.css('.name')).nativeElement.textContent.length).toBeGreaterThan(0);
  });

  it('should be responsiveTriggerClicked', () => {
    component.responsiveTriggerClicked();
    expect(component.menu.responsiveTriggerClicked).toBeDefined();
  });

});
