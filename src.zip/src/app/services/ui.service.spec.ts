import { TestBed, inject } from '@angular/core/testing';
import { UiService } from './ui.service';

describe('UiService', () => {
  let service: UiService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [],
      declarations: [],
      providers: [UiService],
    });

    service = TestBed.get(UiService);
  });

  it('should be created', () => {
    // tslint:disable-next-line: no-shadowed-variable
    const service: UiService = TestBed.get(UiService);
    expect(service).toBeTruthy();
  });

  it('handleBeforeUnloadMultiBrowser', inject([UiService], (uiservice: UiService) => {
    expect(service.handleBeforeUnloadMultiBrowser).toBeDefined();

  }));

  it('setUnloadHandler', inject([UiService], (uiservice: UiService) => {
    expect(service.setUnloadHandler).toBeDefined();
  }));

  it('unsetUnloadHanlder', inject([UiService], (uiservice: UiService) => {
    expect(service.unsetUnloadHanlder).toBeDefined();
  }));



});
