import { Injectable } from '@angular/core';
import { Observable, fromEvent, of, merge } from 'rxjs';
import { distinctUntilChanged, map } from 'rxjs/operators';
import { Constants } from '../constants';

@Injectable({
  providedIn: 'root'
})
export class UiService {

  isResponsiveMode$: Observable<boolean>;

  // Should return a non empty string if there is an error to show.
  // the service will try to show that string in an alert message but it  depeneds on the browser
  canLeavePage: () => string;


  constructor() {
    this.isResponsiveMode$ =  merge(
        fromEvent(window, 'resize').pipe(map(x => {
          return   window.innerWidth < Constants.UI.responsiveModeBreakPoint;
        })),
         of(window.innerWidth < Constants.UI.responsiveModeBreakPoint)
    ).pipe(distinctUntilChanged());

    // take care of unsaved changes before leaving page:
     window.addEventListener('beforeunload', this.handleBeforeUnloadMultiBrowser.bind(this));
  }

  public handleBeforeUnloadMultiBrowser(event: BeforeUnloadEvent) {
      const result = this.canLeavePage();
      if ( result ) {
        event.preventDefault();
        event.returnValue = result;
      }
  }


  /**
   * MUST CALL unsetUnloadHandler on OnDestroy !!!!!!!!!!!!!!!!
   * @param handler this function should return non empty strin if we need to warn user before unloading page
   */
  setUnloadHandler(handler: () => string) {
      this.canLeavePage = handler;
  }

  /**
   * by default user can unload a page.
   */
  unsetUnloadHanlder() {
    this.canLeavePage = () => '';
  }
}
