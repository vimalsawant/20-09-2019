import { TestBed } from '@angular/core/testing';
import { BrowserModule } from '@angular/platform-browser';
import { ResolverService } from './resolver.service';
import { DataService } from './data.service';
import { HttpClientModule } from '@angular/common/http';
import { MatDialog } from '@angular/material/dialog';
import { ConfirmDialogModel } from '../layout/confirm-dialog/confirm-dialog-model';
import { ConfirmDialogComponent } from '../layout/confirm-dialog/confirm-dialog.component';

describe('ResolverService', () => {
  let service: ResolverService;
  let dataservice: DataService;

  beforeEach(() => {
  TestBed.configureTestingModule({
    imports: [ BrowserModule, HttpClientModule],
    declarations: [ConfirmDialogComponent],
    providers: [ ResolverService, DataService ],
  });
    service = TestBed.get(ResolverService);
    dataservice = TestBed.get(DataService);
  });

  it('should be created', () => {
    // tslint:disable-next-line: no-shadowed-variable
    const service: ResolverService = TestBed.get(ResolverService);
    expect(service).toBeTruthy();
  });
});
