import { TestBed } from '@angular/core/testing';
import { HttpClientModule } from '@angular/common/http';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ServiceContractConfigService } from './service-contract-config.service';
import { DataService } from './data.service';
import { ServiceContractConfigModel } from '../models/service-contract-config-model';


describe('ServiceContractConfigurationService', () => {
  let configService: ServiceContractConfigService;
  let dataService: DataService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientModule],
      providers: [DataService, ServiceContractConfigService, ServiceContractConfigModel],
      schemas: [ NO_ERRORS_SCHEMA ],
  });
  configService = TestBed.get(ServiceContractConfigService);
  dataService = TestBed.get(DataService);
  });


  it('should be created', () => {
    // tslint:disable-next-line: no-shadowed-variable
    const configService: ServiceContractConfigService = TestBed.get(ServiceContractConfigService);
    expect(configService).toBeTruthy();
  });

  it('should call getCurrentScId', () => {
    // tslint:disable-next-line: no-shadowed-variable
    const configService: ServiceContractConfigService = TestBed.get(ServiceContractConfigService);
    expect(configService.getCurrentScId).toBeDefined();
  });

  it('should call getServiceContractConfig', () => {
    // tslint:disable-next-line: no-shadowed-variable
    const configService: ServiceContractConfigService = TestBed.get(ServiceContractConfigService);
    expect(configService.getServiceContractConfig).toBeDefined();
  });
});
