import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Constants } from '../constants';
import { of } from 'rxjs';
import { tap, switchMap, map, timeout } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { HttpHeaders } from '@angular/common/http';
import { DataServiceParameters } from '../models/data-service-parameters';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  cachedConfig: any = null;

  constructor(private http: HttpClient) { }

  /**
   * @param uri url string
   * @param method optional. Default is get. otherwise, specify  uppercase.
   * @param payload for either post or put
   */
  invoke<T> (uri: string, method?: string, payload?: any): Observable<T> {
      // below line replaces '{env}'
      uri = uri.replace(Constants.uriEnvironmentStringSubstitution, environment.uriSegment);
    if (method && method !== 'GET') {
      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type':  'application/json'
        })
      };
      if (method === 'PUT') {
        return this.http.put<T>(uri, payload, httpOptions).pipe(timeout(Constants.httpRequestsTimeout));
      }
      if (method === 'POST') {
        return this.http.post<T>(uri, payload, httpOptions).pipe(timeout(Constants.httpRequestsTimeout));
      }
    } else {
      return this.http.get<T>(uri).pipe(timeout(Constants.httpRequestsTimeout));
    }
  }


  invokeFromConfigSection<T>(configSection: string): Observable<T> {
      return this.getConfigSection<DataServiceParameters>(configSection).pipe(
         switchMap (x => this.invoke<T>(x.getCatalogUri, x.getCatalogMethod, atob(x.getCatalogDefaultPayloadBase64))));
  }

  /**
   * Obtains the configuration from the assets folder.
   * it also caches the whole configuration to avoid future requests
   *
   *  @param configSection meant to be a key in the JSON
   */
  getConfigSection<T>(configSection: string): Observable<T> {
    if (this.cachedConfig) {
      return of(this.cachedConfig).pipe(map(x => x[configSection]));
    }
    return this.http.get(Constants.jsonConfigLocation.replace('environment', environment.name)).pipe(
      tap(x => this.cachedConfig = x),
      map(x => x[configSection]));
  }
}
