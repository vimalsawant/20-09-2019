import { Injectable } from '@angular/core';
import { Resolve, Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { DataService } from './data.service';
import { Observable } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { MatDialog } from '@angular/material/dialog';
import { Constants } from '../constants';
import { ConfirmDialogModel } from 'src/app/layout/confirm-dialog/confirm-dialog-model';
import { ConfirmDialogComponent } from '../layout/confirm-dialog/confirm-dialog.component';


@Injectable({
  providedIn: 'root'
})
export class ResolverService implements Resolve<any> {

  constructor(private router: Router, private dataService: DataService, private dialogService: MatDialog) {}

  /**
   * This should be used to pre fetch both the configuration and the actual data from the server
   */
  resolve( route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<any> {
    let url = state.url.toLowerCase();
    url = url.split('#')[0];
    url = url.split('?')[0];
    return this.dataService.getConfigSection<any[]>(Constants.routerData.jsonConfigSection).pipe(
        map(x =>  x.find( item => item.key === url )), // navigation the JSON config on this line
        catchError(err => {
            this.dialogService.open(ConfirmDialogComponent, {
                width: '350px',
                data: new ConfirmDialogModel(
                   'Error: ' + err, 'Accept')
            });
            return err;
        }));
    }
}
