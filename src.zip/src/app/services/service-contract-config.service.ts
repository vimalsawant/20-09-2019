import { Injectable } from '@angular/core';
import { DataService } from './data.service';
import { map, tap, switchMap } from 'rxjs/operators';
import { Observable, of, throwError } from 'rxjs';
import { Constants } from '../constants';
import { ServiceContractConfigModel } from '../models/service-contract-config-model';


@Injectable({
  providedIn: 'root'
})
export class ServiceContractConfigService {

    /**
     * Service contract Id Changes in a per- environment basis.
     * We can cache until code refresh the service contract Id.
     * This code can change if a multiple selection of ScId is available
     */
    private currentScId: string;
  constructor(public dataService: DataService) {}
  getCurrentScId(): Observable<string> {
    if (this.currentScId) {
        return  of(this.currentScId);
    }
    return this.dataService.invokeFromConfigSection<ServiceContractConfigModel[]>(Constants.jsonConfigSectionServiceContracts).pipe(
        switchMap(result => {
            // validate that scId is properly coming back from service and it's non empty:
            if (result && result.length && result[0].scId) {
                return of (result);
            }
            return throwError('Service Contract Configuration Service did not return a valid Service Contract Id');
        }),
        tap((x ) => this.currentScId = x[0].scId),
        map((x) => x[0].scId)
    );
  }

  /**
   * As opposed to ScId, the below object may often change if a status  / user integration download Id or
   * some sort of current data is shared.
   *
   */
  getServiceContractConfig(): Observable<ServiceContractConfigModel[]> {
      return this.dataService.invokeFromConfigSection<ServiceContractConfigModel[]>(Constants.jsonConfigSectionServiceContracts).pipe(
        switchMap(result => {
            // validate that scId is properly coming back from service and it's non empty:
            if (result && result.length) {
                return of (result);
            }
            return throwError('Service Contract Configuration Service did not return a Service Contract Configuration');
        }),
      );
  }
}
