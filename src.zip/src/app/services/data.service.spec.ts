import { TestBed, inject } from '@angular/core/testing';
import { DataService } from './data.service';
import { HttpClientModule } from '@angular/common/http';

describe('DataService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientModule],
      providers: [DataService],
    });
  });

  it('should be created', inject([DataService], (service: DataService) => {
    expect(service).toBeTruthy();
  }));

  it('invoke function must be there', inject([DataService], (service: DataService) => {
    expect(service.invoke).toBeDefined();
  }));

  it('invokeFromConfigSection function must be there', inject([DataService], (service: DataService) => {
    expect(service.invokeFromConfigSection).toBeDefined();
  }));


  it('getConfigSection function must be there', inject([DataService], (service: DataService) => {
    expect(service.getConfigSection).toBeDefined();
  }));

});
